package com.youmee;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.text.Html;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.LinkMovementMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Base64;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.UUID;
import android.view.View.OnClickListener;

public class Activity2 extends Activity {
    public Prefs prefs;

 /*   static {
        System.loadLibrary("il2cpp");
    }*/

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(1024, 1024);
        AlertaNoob();
    }

    public void AlertaNoob() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("                            ALERT");
        alert.setCancelable(false);
        alert.setMessage("                       ESTE MOD NÃO É GRÁTIS\n\n                       THIS MOD IS NOT FREE\n\n                       यह मॉड फ्री नहीं है\n\n                       ESTE MOD NO ES GRATIS\n\n");
        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Activity2.this.Vendedores();
            }
        });
        alert.create();
        alert.show();
    }

    public void Vendedores() {
        byte[] arrayOfByte = Base64.decode("iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAB3RJTUUH5AgFFgwyOmaJiQAASlVJREFUeNrtvXe4Xld15//Z+5zz9nLf27t0JV31Zku2JcvduBcw3RCSEALDEJIBMiG/SYVMJo2UoadAgIB7791yUXFRl67q7b2+vZ229++P91qYmUmCCQZ+8/y2Hz3y1fM+7z1nffcqe63vWlvwc1r5uTx+wEdogVIKKSUAylemYRpNWuklwEotWKkFywSqS2jdpLVMookCIQSmQAOGp9FV0CWByHlKzXm+NxaUYlCY1mk0p7XWI1rpOTNger7vAyAQAEhDkkgkfi5yED/LX6a1Jp/PIqXA83wEgmzCIJHzm6SUa9Gcr7XeIoRYA7QDCS0IaAECDT6ABDQIjRACNGg0QtcEqrWm6jhoqQiaAaRhOALyGiYF4gSwX2n1GnDcqbPmAhkXLUAYErSmLpGsfe//TQAsLCxgGiZaaxDgewpp6BaBuADkNRq9QwixHIhprUEvPpyoPaIW1ISuBWgDIRSLYq+9gFBoQCNwqzbKdTHDAQwjAGikWARt8fdrTVEgBrTWu9H6KS3Fq6bPjFrUJ+Er/IBFQzz+/20A8vk8vu8v7igBWgeATULqW7TW16NZLZBBhQYhEHpR0EKgVU1Yb5gJpKrtcGXUnlrrRQgWtQtwfBe3XMEwDQKhMHbFJmhZGMEAoECrRXBlTdC132dryUkQjwt4AK0PY0inZtkAT1BXl/j/FgDZUhbh1QSJ0mhERAhxmVLql9FcidCNSvlIaSCRKPHDh9GLIIia9M/aaq1ru7wmuUXt0D98BU3N9CjHxQwGqThV/FKZxqYmtCF+9Pu1sagMNVOmBQitQYh5LXgO+BchxAv4lAUgfaiGNU3Rup+6rORPXfgLebAl2gckIQ03oLlTKX038AENjUprhDQQQv5QqJqaiRECLQS+9qlUy2dtvF60S0K8oRMCpPgRe618D89zKVXKzE5OkqirQxlG7XsRaOQPzRkajXpDM2vaoXSj0OIDAnE3St+J1jck6hKh3bueI1woMtJ3+BcXgMJCgflSBqRGZmNCwzbt6e8IxJ0IbgIdPWvclcZAIrQ8a+uFECBrssqXSxw8coiFySmEFGd3uhBvbH1xVoGVUvieR9V3mZmcolqqkM9laalrwAyFqKmXfJPpESitAB8hwZCLGiQXv7umFFHgJiHlnSeG+r+Tdyrboi0dItnezbSboZQu/GIBMFfIYgc12BohZZtOFf9EwINoPqgUMa0VQtTstfYVQgoU+o2NuShLDSgct0r/UD9+rkRHd9dZkyOFsegDPPSiLddK4boOGk02nyefL1GybQLSJNnUiFD6R55TaYVjO2glEFJQsCv095/GUNS0UfxQNwQCFxE7cLTvg3Ej8OD8xPgXzWCoLVIRaHwK2dzPH4BSuczUzDTKdmmIxoWh5TXK9e5TWv0BQrTUtrZaNDUG/lkrI2smQauzZsXXmkKpzMzcHKWFBc455xykGUKrRfusNVqD0gIha7g5jo3QmnShxOTQKFbApFrK09LcXDNPixGU0KCExPd9AlIiDY02TB7f+QInXn0VYRioxShJnvU/BkdHh7n9n7+HKpdbgtHoH3qef59Q4pqoFsLVPnPpeRzb/vkAMDc8xr5wCcu0kJrk5Oz0H5aqxduVcrdLWdthZ0NJXbOzAoEpJRKBEFD7nMR2HebnZikVyxw/foK1PSsIxRM18yFrQtRS4+MvaorE9T0c10ZISd/AKQoz0xSdCk2pRsxgYNGp1l7Q15qxkSG8chFhSkxDcrB/gKfuuJtNa9eBVEi9aOJkzQcNLUzzzW99g+FDh0jW1WO7Plp7232lbi9I/QcKkiEzgOUICoXCzxaA119/ndG5aRpOz2NZZq/tud92q9U/FtqvlwGJFvps1CEWpSClgbFox/Ub0Y0QVByHiclJ3KrNiZFB4p6ktasHXwp8w190vjVtEUrVdrMC1/ewpMFsqUg5l8MMmiSsIKmWZt4IUDU1DM9MDHPylb0EAxYmkslMjr/6y7+gzQjQtmoNygOhahpT9j1e2LuLO77/L+RPDfDuW26moWcpTzzzDIWpGRyt613f/4KJ+LZpmL1FXUVKSbFY/NkA8Nprr+G6LslEEjtfuig9t3CH7djvEVrIcCSGFBZi8T+EQEgT39dUSxW01ujFyEUKieN7TM/O4jkOZjjKwtgEG8/ZgBYa6ftorRGLmuN5Cgdqu037CB+UsHji5Zd56sFHGD3Tz5Kl3RiBUM3GLwJ/sv8Mr+zeS9iyMIJBPCG57bGH6XtpJ1dfdw2BcPishpWVz32PPcpLzzyLmS/x6U9+kouufgdFJIcOH6b/2FFMQ6JQEsR7PN+/Q2l9keM4aK0oFnJvLwAHTx5FBAy2b99Orli4ORKL/Iun1RY8RTQSwzSCoI3avl80QXPZNK/s3U16dhopJUKAq3zyhTxzmTT5XA48n0wmzebVa0g1N5Mu5CiVy4vOseYUTWkxOD7GVP8gqNrpdv9AP88/+BCF9DzdbZ3E4vHFkFJqAWp8Ic2DD9zPxJnTxJL1GIZF3+Qkd3/v+1y4ahXnXX4JPhohoKoVdz34ICeff5me1g7e8Y53kOhooaGhlZHJScqlCuPDoxjKR0j5RuywRUr5L6Zp3iyqISxX4C4U3h4AZk+dIqolW+vO5djxQ7fG4uF/DIaCPQgIh8IEgyEEGiEVjlLMLEwzMzvDqVOnCJkGLa1NCEPi+j7phXmKxSIDA0O8tns3YwP9JAMBlq3speT4VCtVzGAAKSRCSISEiUyGB267HaFdND5Z3+O73/0OU6dOsayjfW79li1VjcQQCtutnBnNLhx77JlneOHxxwh5Ls1dHXhS8sq+/XizM3zo/R8g3tQIQlNVigcee5SB1/bTsaIHTMmxgX6OvbyHkmuz5+WXcColFooZMrOzSFELpVVNy3s06h90oPrBYGovJzPz3LZ7108XgLGxQZQheGR1A4POyQ+FIvGvSDPUYjsKQwmi4TBIUPgMT01x94MPcvf3b+PMyZPEQhGWdi3FjEQpOzZzc3NUbZujp07w7LNPszA5SVd7O02tbSBNquU8qUScQCAABgihmKtU+ZtvfBU1MUN37wp8YfLw80+z+4knWNra6l96xZXVeGuToRe9vlA6fmp0pOH+++5hfmyapmQD9Q3NTGRy3H/HbVyyag0XXH0NPibZUolHHn0YkSuydM0Kdr/+Kq+99ir5mVk2rFlDvD5Be1MDS5cvp627h5mZeUwEviFrhzdAKd2qhfjqTO6CD60v5vDnszz84CM/HQBODPThKx9HSN4/UrglGIz8XdgMNVpI6qJxGhobIGAyNj/L3Q89yB3f+x4n9u0nM5/BK5WJh4Mk6lKUbJvZmVnmMmle3LOXvbv34OcLLOvppqm9jUA4RKVaJBwMEgiGkIu5t/lKmbsffJjn77mXLeduJJyo4+DQIN//+39kWXMz69asN9as2tBhWUELDY7jTs4XioXnnnux48SBQ2gB0UgYgia3PXAP1uwMv/6p/0y0oYmy7bDn4CGO7nuN1qYGxucXSMUTrOjsZvOqFXQvWYrheKRiMZKxOEYwwEKpwPj4OBLI5zK1xJ8MIEzZWKhW/u5v9h24eaYhTGfP8h8LAPPf+4BDiaAO4eFfELSCf6uxmivFArFQCDNgkKkUOX74NM+98AJzw0P0dHfT1Jxi7dLlrN+0ifqWVqqux8TkJPOzcxw/c5LBU6fxHZeutnYkYFkmnutgGQaBQKjmQA3BwMQETzz9DHffeQ9L4jF61q1ldH6Or33za4QdDyMQoKutlebuDikU2K5fGurvf2VO+dt273wO4XrIgARDMJlZ4Mz+A/zmr3+cddu3UXZdTp48QUMojIwleOHFF+kbGWFhchRnepY4Hl2JOgKxBBu6uumfmsJXimq5xNz0FB0dHZSrNqYskqgLorQgEgg2m5LfHfrBvS+/3Nub2blzJ5dffvlPDsCZ/jMopUkXMmZLU+uHDcNYWiqVwAQHn3KlxCtHj/L4fffilks0hqPUhSOsWruO1WvW0NTeQaFUZuBMP+lMhumZKQrpBSKWSUNjEzJsYWIQiSdRUhIIhmvxkxS8euo43/nKNyhkM6SHBvnYR38Nq72Tb37ru+TPjOAoj5ZwnGvf9U4IWuSrDnc+fF84MDN3jdfeHp0cGkFISV1DIwXH4ZmdL7C2roEtl11G0VccPnaI+alZhscnOHikD5WZRZsBqoUSC3qaEy+nWR8IUvUUXl2SjNJo02T1uZuxgmEcTyHNIPMLC0QTcaRhEAuFSTY2rLMC1sb+vmMvrtq+/SfXgJGxMfLZHOvXr2N8YuIiywreUC6XkUIgrDATYxPMZjLVV3e9HKrmMgQCASLhMMuXLWP1unU0NjUzNTvPyb4+pO8zMDHKiaNHKOWzrF2xknBdFGyXcy+4ABEMYalaasz1NftO9PFXX/pzzEyJoZlJNq3oIb68k698/RtMnRlgOrNAdWGOP/rvf0qqu4u5XIFHnnuWp++7T164bEW0cUkXZjiELpdwlCZXLON7mjWrVzG4sMAL991LaWGOUCLG8ZNnGD5xEkM7+L5PqzRoz2TZbgQQ+/ZzqP8MbkcnE9EYFSlx8Ek1pIiHQ9R1LGFurkIxnyNZ10QASU9Hd/JUNHnBof6BFz/S3fGTAXD01DEu++Z/4oVPfoOxiZElASv4V45jd2mws6Wy+frhg4cPvbTrwdbu7mg+m/1tKQzTCobp7Ohgw6bNBKIxjpw4TmZ+HtO02HPoEF4uz+n+QdzMHM3hKFs3n0vvurXEG1No36fseWRmpsi6mi9/9SvYE5NE2rrwBgcJ9SS575FH8Cous/kMVMp87lc/ysXveiflqst0ep79+15HlUsUtCY8Pc3GDRuYHx0gJExy+SwJwyKjFF/7k//O3PAwTXVxVq5ZQ1NDE0YwQDGdI+h6RCs226wAV1x3DX59ivTsDC8d60NsWI9IJpiZmsbTHoV0msaupRSrVWanp4nHk2AEaG5sxGys2/i+ppXm8At7vX8PAON//YdXXnuVlvpmPnbejZQqdjIejf2mEuKD8/lc6fDpvgOvH97/pSMv7/2jS6+7dnZuauIWrdTaYrHCspZW3nH5O7CDAQ4dOoSpobutjUAshl2qMDA7yZ4XX2LN0m5uuPkmOntXcmpkjGOvvk4qkWJ0ZprxsWFOjo3y0pNPUxeOMLMwS2tdHanmJoq5MplMBuwq73rHNVxw/TUcPnqCV3a9iF0sMDA6wqrWdkYzacyqgx8yGR8fpVQooqo2Hct7+f59dzHeP0C+UGRuep6w0Cxfs4rx2TlM16a7sZmmWIwlsTBtrsaqq8eoT7L/8CGGCiXqmluINqRoam4jGArS2t5BX/8gC6OjtLY0E4xFyRWLzE5PBY4Nn7w/NztXuPkTH+SZR5768TVASINCpQiCRisY+LtMvvDebKk0cKq//7Z9+1/57oaLdgwtX7/h+syp/q9fe/mVSyvBAEf37mX1ylWcGh+lPp+jOZFCC5jJZslmc+QW5kmEozS0tjA6Os7zL+3lq9+7DZXN8f6rrqWyOY/rVhiaHGP/gT5MTzMyOUk0HKapvZupdI6JkRHCAYN3bL2A1dsv5J/uuIPXd+9BVkpsOec8ptILtG7YSHNrO6/sf41oXQJDG5jRGGYgxKuH9jE1Oo5WLp7vYgpFQMLa3lW8dmYAmcvQ0tHO+Ws2EsgtMDg/T9wpoY6fJhiJslAqYk5NsWL9JoQwmJlfIDe3QF2ygUKxwPzsFMnGRsLBMOnMQud4fm79icmhiU9v3vbjm6Ann3yWYDCAFQqjfO/XssXS+/pPnb7Xde0//8gHbu2bW5ghqMS5x/a8+tcXdC9Zun79Ok5PzdDS1s6rfUeZHhjkmosuoRIK4SnFgX2HmBobZVVbBze94wqCqSSHn3ueXQf2U86UWNbRgoMiGI4yMTnOrpd2MTM+Sz6bIZ5KYkiDU6NjjE1M4dsVLlizguVbNnHfM49zeM/L2GUPUykc5YDQnBzsJ9HUTKlqIzNFQsEQWnvMZBaImY1IaeI7HlILtAQraNHV2EhbexulU6coC5+iXaVt7VpM7SNKJdKmIJGqwzt9nJlsgeGxUcx4FJWqY3J0mJaeJXiZEEVbkcuWqEsk6entjR3evfum55958envf+d7+sc2QS1LGljStYx8NrfeV/pDmWz2tuGxsS9EwuHxJ594jPa25taFickvr+7o2r7jHVdgBEJ4UnL0+AlO9B2lWipRFwrQtWwp2jCYmp1n4MwQR08ex5mboblrCc/seonM2DjdHe3EAxbvvOWdyPp6nntpN08/9RRTg6NUKmXmMmlm52bJZLIo36GjqZ5LrriS5w7uY++zzyOUj9KSgDQIhoOMTU2jPZ9CsYDrOPiqlksyTYlCEA1HmJtfwPMcHK0RSrGyu5vL33El847P5OAgLe2dDE+MUB+P09y1lHh3F0bXUlRnJ8m2FsZyeex8jmU9ywlEw1SrZZKxGHPZPOVsgSXdS7DCFu0t7RRR4SfuvOcBpCz+xmc+wx233fbvA/Crv/Ix5mdnLWCN47n3u7GmR5zcnPPnH/8UPRvXb25IJP9my/pNN2y5YJuwAha2p3n59dd54ZknKKYz+J5DMhxm6YrlxOMxgrE42XyBbDbL6NQYjz/xJOnJaZrqG5Ha49ZbbqFj3RqGRsZ4eueLjPQdx/N8PBaTcIsVqpbGFKtXr2RwNs2ru3cjPA/f03iug+PYzMzOoVyX+lQCKWXtO5TCtSsIIVGOj2VKsvkCjlMr4GjfZWvvGi679mpC9fU88/QT9LS1kUNz/Ogx6usSdK9diYglSXUuoT7VQEErivPz1KfqSKZS2MpDlauY8Tinjh/j/I0bsKIx0vNpGpobzfqO9teae3pOW2aAc7du4anHH/+3T8K+Vmgp1MTUxC4pZP/g/hdxKqXAhz//mWsb6+uvXbNsxdrOrk5hBgJUNew+cpAXnnoSXa0QCcXwlclUOs3I8ChTM7Mkw0F6V/RQ9l1ODg2TSadxfY/Z+Vm2rl5L93lb+Ofv/gtH9r/OwJmTuHaNo1MrvpwthbFQLPLC3ld4fe9epK9BSJTS+J6HpzW+rzClwIwEcYWH9qv4FY9q2aVasfF8D7tSwTQttK/BU2ghePXQAQ7ufRVdsRFWiIWpSZra2pgql3ngycfoO3wEwxBEoiE8qelsaiLe3ETYMnE8j8npaUbHJwhbJsqAfCaDlAZj5Zw7NT5+v65UOgqT462F+RkidXX/vgbccNONSIEOhULqA+95L9fceMPSYrF0lXKc6iWXXjza2Nz44fr6hmgV2H+0j6cefoTS/DxWwKTk2rhOFc/3aGluoqJgbnyKoBA0NTSyZcu5TGYWmJuaYUN7Ox/86K9w5zPP8NgDD2CUysyk01RK5cUSpXoTTQJ8V2GaFkL5hENBUvUpDNPCth0QEDRN1vSuoHPVWqZn05QLBSrVKrbnYkqDGi1I4fqKYqFQq6ppQdXzqNplxqdmmJ6coK0uSdZVnDh8GNvzONU/SGkhSyhoEKtPMjs5jYmkLhxAhyLMzs9hKMGy7iW4+DQmkjS0teE6jjF45sS9rY1N3/WUMkzDKPmGyQN33fVvO+FPfeKTAHznth9wz0MPidHxYWmYxkuXXnn5ZGtr6411qVTUMQz2HT7Cizt34paKuK6i4jhovDkhCVYcO5Gdm2d1zwrSnqKtKcW5WzZRlZLn9+0jZp3muptv5LFXXuXR++5DVavksllc20Zr/yxhUAhRq6crj/bmFiL19QwNDFKfqqNneQ+z6RyVik0qbHLVpZex5ZJLOD0/z6uvvUaxUMDzHIQ28AwDIYOky3lKlQpera6JJSGaSHC0f4jg2DgNyTpOTkwxMjGJ67gUFPhkuP2xR9j9ym6uu/46CIbxhQ+BQM2RI5CGgXJ9ujuXYkuBZ9s0JZN+R/cyd9op52KLJjFsGD9+Ms7zfGLRmNZKDybi8cnR0oxobGi81DfM6At7XmXXczuRtku5VMV2qljC8BrjqS9H6uteR0jsQpHeri42blxPY2sbQpq4nsYQgisuvpjj6XkeeeABlF1Ga4XtOijXQ6jFBxJmjYDlC0KhEOFEjPnZGZLRKMs6l9GYasY0TYLhAIlwlPM3nsumc8+nojTZTIZqxcaxNa7rUqyWKdtVKk61Vr/1FUIoItEgCA+3WiEei1DXUE9FeVTLZXylqFQqlIt5fDzG5uZ55slnKGfTlCoOhaKNXSrjV12U71GulkkGI5jhGOVyGRkIqYaO9uKqbefR0tmNW7XR1eqPfxL++K/8CmfOnGHLxvWYUqK02qoM85deP3SAI6/uJmwFGJwYo1wtEwxIGhpTA5FI/JD0qhvdok1F+cTCIUrlCsVsnvqGFIeOHCLi+4ymM5zYsxvfdRG+QKPJV2xcx0UIhUAu8nU0UmuikQjpbBbf84lGY0RjUTzAtqsETRMrnuT+Z5+lIAzmp6dxnSr4i2VMIXA9F7+s8F2FUhohNRKBNAJYRoCm+hQtLS3kqhUWFhbwPW+RiSFwbY+QaRKKBDAiAUqOi1usEG3vJFctYler+J5PLpvDQLGkfjVVu0xUxawIVsqsCCrS5P3vf/9bzwUl65JopciXitG6uobPTGdyrUcPHaUhlmRoegrftmmIx+jo6FSReMyamZtbNXzsRMe2Hdv01vMuECf7+gjX1bNu4yYOHu/j+Weeo+/YMWZmFxAIlK7VYaXQOK5DfV2Sqhcmmy2glI8QGjMQQGsD13axzAAIyan+k2AFcBybtvYWgpEoM9U8377tn5nPFTGURpsGUhr4nofveShfoRRopRdJieB6HrFoFDMQZWhkkpHJMaqlMlKLs75Ho1G+T9gK0Lu8l6zjUM1mcKRPKZf1tOMYyvdEplxkYW6SFWvW4jg+UcdBVarnqWrZCgjpvuVc0NjoBL6vWHDSsivR8RkX3td3+gRhIZktl8jnMsTjEbrbO0mlGqXr+0YkWupe0tm9K2c7s3fdd/8tyzrbWLd2A2sNk+NDQ+zatQs3n68V5qWkOZFg7Ya1tHZ1USlXaKlvoHNpJ6MTszz7wvMMD/YTCASo2BVCVgBfeczOz9Hd1sbyZT141Qore3vxpcQtVwk1pNjz6uucOnIYX6maDimFQKOFehOD1ECjqFarLGjF9Fwa17UBdZatUSP71hhCSvn4PuSKZSYWRlmWSFG0bSbmpnemwslVPrq7VCrpof6Bg5dV7eVBoZMaD629Ta7vdwgph98SAP39/fi+R2dLO5Fs6MPKEL/TPz5qTfefQZomC/NpkrEErW1NRMIxlO+Xg0FzZ31d3b2NF7ZPnhwe+iauR8/yXrqWLeX0kYNMj4/Q0lhPJRgml11gxZJOdpy3nd6167FCIVJ1DYiAZGxilIu2nsNll13C9+65m107dyI8F08r7KpNMh6nqamJkfFxUqZkSWcnVUuysqWTVM9SIg3NLG1vJVcsMDQ47M9NzwvbKUtf+aAFAnWWk+QpH79UrfGBUBjiDQpkjcookTX+qFYELYvphQUmx0Y5/6qVFLN5fNd9NpwynEDQ7LYNqfK295Dwvff6yA0KjTDNqWq+7BuW+eOnInbu3IllWphGPTPTczeFrNBfLpRLyaHTJ2luqKdvcJD6WJRIOEyhWnHmFtJPLW3rHsD1v17X0NCvDeOW1UuWbctFY3psckIc6TtBZmoKW2hWLOkhHk0yNT3GsuU9EJCU7By4Lvlinpa2FrZsPpfh8VGalebTv/mfyVUq9O3ZhZIQj8bZuHw568+7gEPH+5idmuTBhx+jKn1uecfVrEsl6UrVs+N9H8COBNmz8wVlBULy5Ik+cpkc89ksc9OTFEplfMetCVfU4hDxBiNe17hKb1AehZCY0iScSJLN5YgFQhTKVRytnRTGqUomt7yxvoWwZfqlUumYYQZS0mOD8DXJZPJ7bW2tYwOjo28tHV21K9j24Pq6ZOqPPc9rGx8dwvIV2gzQ1FBPTs+riZnZ14u59G1dS5cMzubSx7rbO0ampicJGKaOxxPfjCzpqLiOf2sgFFuVLxRRuXkM0yARjrDhyqtJV0pk52bIFwvU14dQnmZ+ao6lLR1sPX87fceOsdoMcs3111GaniAVT7Awl6anrYlV61ax+dzNLORzREyLF/uO8OQLL3F8epLBE6fZtmoNHZs2EfSxtu/YTnN9iq6OLo4N9hNEsVApMzI4zNT4FJ5nk04XqBZzCGGQzeWwFolg5XIZISSWFaBYtSnmC5yzspeqYUC1UnClHsFxSiAxS5XRRDi4Lz086YcaYr2ReKLBNAPjJcclqPVbA2B0ahIhhBwZG7Oak3VkMgtoJRidGKOYy1aK+dzXnELhb87Ztj1fKeVDudl85q6HHkLCisZAcMuKlb1/+4U/+/O5P/iz/2G7uex/jydCZqVkIIQgaGk6O9sxCkWymTT5bJH6ZAMYBo5WjIwM0dndxfKVq0hPjLF1wzk819xGYXYGS8GK3lXEGhvoP36SpnCIzRs2EGxtxF+7gcTSLh69716aWpqpuDb9k5PkHn4E7bj4SiPLJc7fsYOxfJbzl60ktayHI0cOk57LsGfvS7hlm2RdgtGxUUJGgFA4jHI9tIT0wjypaJi27g4yhSqW5LSLHEC5E772mc0t7L7r7ntGLzpve8CcMr8SnxhLmoZZ1Fpz6y/90lsD4NTYELlqZSFR9Y2GTZupOC4z0zNUC6XpiDT/ItzS+vdCGnYxkwmAMNpaWym/+AKJhvpN5Vzp8NEz/bO/86W/ajlx/MR7goWs2bFiOcFIikrRJRypUVfq6xKE41HshQzlfJFwXR3S0ORLefLzczQv62VsuJ9V8SiJjjb2PPU8S1saaGhsYqFc5p777mZFQyPlfIGO1b00LFtKOJFk9fIVbF2zFpqbyZVLbF22jKzvseulXXj5HJMLWbKzM1xx4XaqwQAU85xzzkY6uzp4/IXnYGSEbedtwXV8ZvNZpsbG0Uri49CaagcrgGdnSaaiJ5O5QiEvzVEhpSo5qu/zf/hHjKWnBpKx2NDY+NjFViCQ00q/NVbE8VOn8OdyJMpee2tT86HpXD47cmYAp1Q8EImEfundl1/3Zam1HU7E8ZVOer6XyBQybLzsIhmQRtyMhPbIuiSDY6NbTpw4vn5hcrJmX5WLlD6hcBRbCQJa0pRqBtNiLpPG0LX8T9F2mJiaQCobywwg7Cqr16xFSMGm3hX0rF9L1fWxDAsZi/HAC8/zxP0PMTk+xvDAACFhoE0DS2mWtLbR1N5OPJbg6m07+Ph/+iSrzt2C59gMTk/zyAMPYCGp5ArEkwmuu+Aitl5xJY6vCUWj+KrW2eNpjak1Ha0tRCIxmpuaqI8nhoOpeiLSnI9Ggun6hroTIampi8R1fj7rO64rSsWSXS6X3lpJ0jBN7EBE+NXikoVc/pnC1MwqHG/QtKwveCX7xMN7d2LnikyPTSCioY2hQCBtVyqUq5WmRCSSTyWT01/+h79n1SUXX+XMz4eiK1bglmzC0sANhrAsCy00rnJobEgyPR+imC9QLBcJxmNoBJl0nkqpTNX3mJufw1catdhXNjIyxujYOPOzC2BXEdEIj+98ljPDZ0i0tFAXiTM5O02kvp5iOkdYSSrKZ0lDPVY4hGVorn/HFXRs2MTcvXdyauA07b5gYWaaS7ZfwHS5BMJkIZtlfnYWtMB2XRqjQc7dci7ZQBDhuOXGVGrfTNUjOz2frSuVhoOtTSftcpnf+/0/4nO/9V9AiOOgy2+ZllLIZdFaJ7TSC8VC4Tmp2R+Jhkd9188bzTGo+Mw7ZSItqWC1YpulUumUch1M0+gyDGP41MSkWrV9x/LS7Nw17Yk4vmHh2lVEIEjACiMU+J6N1pqAFSBW14BdrpDOZGiPRFBaUHZ8cpk8hmXSNzJKYXoaIQVP73+dV06dwkXguQ7ad5HFKj4GR/tOUT83T10ixdTkLLlKkcJ8mobGRpqam2lpaqKlqYlAwGDt1q3YpqSzvpntO7bz1PMv4RRLnBoZorO+kRtvvJbTw8PY2mX4TD/atVnRvoL155/P7uN9KN97pFquvjAzOIyTz5VHTp4c0DMz816x/MOeL61nONtC9RYAsGtc95gQoh+MjCXNjK8U0pA42Qq79uymc0k3ApoNQ47poFWuBhCW7celZR5anWgQJ/pPvz8pjRWpxnqdiMbmPa3r8JUVME08KfEdF8/TBIRFMhYjE5BUyiXsikMgGAF8fN9Da0GhXKGUy6KUwtWwkMnjSzAMEIbAclxELbvM7PQcmfkcWg/heDba14xOTiKFJBgK0lLfQDAc4lRfH+dtu4B1K3oJJxtY3tFBzyUX8cSLL5CZm2fFyl5a29pIpZoY0icJCcEVl15KorEV4fRRV5fcZcbj5YPDQ1hSFqLl8uGeLlX2F7mwjlaYpnm2LfctAeA5LkqrLAjHEdDR3kG1WuW3fuu3APi9P/wDcpOzaEs2aBgvV6sUKqVEQBrub97w7uxvfPlLG4OeuqmtrWUmZIXng5YxVPa986WnOprrUihMlCdqJ1GnTDRgYZkBfOFRzucJt4QwQiZCGjhVm2AwwOTUFFKos/1jhqj1GpTLJaSoYkiJ1gqlFErZP+ziQyJ0rZ5g2zZDE6MgJf2Dp9i1ey/rNmxg8znnsnrFchobGli+fCVPPf0M+w8dpTmRwBAWXsklEosyvTCDch2E1k7aLo8aUtG+upeQppxEjHUGQ/5kPATAV7/61bdEzv1RH2CYSEOVULVK1Cc+8Ykf+XA6nUGGA6YphJKQrebzWIa1VGgd/Pw//31dtVL6dFtLU2d7T2dFO/oFgRHSvp5VyumwQgbZzCz4Fepb27GVh2WYxCN15Co2tlvBVS4B08IPmKTn55gYHaPv4OFaQwDGYppAn80qaBZzPG8UbxaTaBqFlgIpDcLBIAqN54HyNWiD2UKR6V27OHb0KO95100U7CqpaJxAMsZLLzxPb2cX8yUbyzBpammi4nkEhSAWDroDU9MZMxgiFokScDxtup5R1FoGTMv/SfoDfgSAYrFQc5T/murUciwhT8p82fe8RCyG6/kdpmkUmJ272rICy7qXdO1pbG5TXtXudtLZMzHLmg5pqcxQUI+fPG349XW6vrWl1p8nFHX1KTLZeXwFbrVKPBRiJp/h4ccf5dThI+Tm5jGkdVal3+iGf3OX/NlWHFUDRQuJQCA1NSazIQlYQfAk1UoF3/cwpcF8ocADjz9O+8GjJOoSVJUgEo8xPDNDKV9kSXMjN150ER/55G+w+9Qp0kND6toLLlKO6/HamROITKGCdkbncnm++d3v8PV/+NYP2SU/Zrf9jwDwl3/5l//mh1UNGFP5XtbS4PieqbWuzkzPLU8GgstiLW1/6khjMp5IvNcPOh/LVKsP+K5zRCpC44OTyfmZuXOdYrHfSiSSbc3NzWYyTkNdjKloDDuTp1oqk7Ntnr//YXa9tAtVLiGFwDQtQON5i43WUqPfaD1VarHhQyAD4g1VRiLwHZ9K1cEwDQxDYBqS3q4uoo1NHDt+nGo1z1w6R6XiU19fh0ZiCchXKwRMwaql3Vx56ZXEWtuoGxnjhpvfFWzoaquXQnD0b05QNKVzpn/kpcf37AobpvkuYBzY+xNrwL876wGN1jqPENr1PUzTDGWzWaNSKHQGLetrM3Pzsx9934c4PT6C0kxqy5paGB8/FY7Xrdvff6S1kkufO2a7h0cyOdUQi7x/+dJuelasJBgMMl/MMT0zy0PPv8jYyCB+2a71B2hds/Fa4gNSqFo7kVjsZxSLGqF9hGESsAIgDZA1Z1itVLFtm0g4RMS0uOWqy7ju136N3/+rv+PU3j0sLGTwPUWhWiEZjmJaJsp1aW1pZMPqVXRvWM/I6CjLW5tpXLrUHpuZzhlS8hdf+wae61KpVHzDNJcDvw0cBw4D5bcFgMX9pQB838ewLLecL7RY0nis4tiz7/z1X6d/apRSpfhgtVo9VLKr/QuFXCUsGJ3P5g9Wy6UPRzzdNDM95ZXCAUbGx5B7XsFTCsepUqk4CHyU49bYDFoQCwZItDQyO5+Bil+L7kStY/KNdnlBbY6Hcj2CZoBQOIKUGtdTaB/cSgVLWkjTJFssMz09jVepEg5HCQVLmKZJxakSEQJXala1tHLTh9/Hts1bWKiWmRwa4JJtOzCD4RNN8bpjSimAOtOyvLhlFRcFXgXsxUd5ezTgH//+H87+/3s/dCuVajUaDIXGwom6o0IKBg/s4/3veh+v7n+tr6Wxse/kyJhQQoTTdnXUcb1pXHfSikRfzbt6o5vJk6pLkAiHCEWi9A0O49kVJKLWvy5AK5/ezg5u+vCt3PfkUwyfPEW1XESrmg8QstY9o703hndobNdBOCaO7WM7FdCqlloWBlVfcGp4HH/nTmZGBqmUCnhereNGCIOi6+E5FW569/vZfvkVtNTVk7erbFy9lnhjvSel8WKioy27KIJ3A9uAvwIWgDSwcxGEtweAN6+QZeFrfCMSftUpVz3lutz+7dtRvsJbnMczOzmutVKe7bgZT3llDQs++lXLMq+tVlzSmTRRrbj1wx/iZDbP3ud3MnD6NL5bBQRBKVnTu5JUMsW177iSsTWref7555gZHccUAlMaWFYAI2jU+EDax5BgK0XVrp5NM/toXN/FMgIMzkxy4I7T+I6N57q4novnaLSWuAGX7lSKzuU9RMJRorEkS7qXIk1TZ7K5r6bqkn9WKpXU4myhncA7gM8AXwNG36r9/w8BYCuN77j5qBXRgUgIv1wrOv/gu989+5nzNq7l9cqUc0VdbzWFGSiboUxVGIZfqTTVp+oo5AvMZfLMjY1xwfkXsH5lL089/hTZ2VlCkQCm0Jx74fm0L13K8bERTh3vw9KaRF0C23FwXQ+vUj077ElKCARMpDRr0Y/WZykuvudg6TCGGaRYmEX6Lq7vQo0kARJCKLadfx717R00JOtJJOIIKRmdmT6wsJD56672tmxLY8MbrzcE/D7wX4GPA2OLWvCW5g39xAC4vo8U6EqhiNCae+65538nHRkmVydWoLUeVUo3pcKxSFnZt5rSGEjGE6F8rpDyhM+xgUHsaJz59AKRoEmkvRnTsihVq+w/dpRjA4MMTU4SMUx6e5YhLRPTMhfz9wGCwQDz6QwzkxOkc2m075wtQOpavIvt+sTNAN3LVjA6No7n10xTKlVHQ0sz2fk51nd2cNMt72bt1i14tkNmZoaGjvZq0a5+ZeP6dZNf+vLf8qf/7Q/e/IpDwJ8BfwE0vyHPs2HyL8LApmUre/ELBWxDLktq/W1Tym9WjGDOU/q/ZAv5pcr3VuEraQQsfL9GpEJoLCkRAQsDgSEkhmURMMOYlkEgFKChLkFdY4qAFcI0AvhCUMykKdpVzvQPUi4U8Hwf5Xp0NjWzdsNaztmwjoMzMzx19/1EgiHe8+5buOzyyygU8rz81FOsW9nLhddeh+O5pKcmae3qYuWatacb6xuuLVcqQy/ve43rL7vi/5RmuBH4b4tAPPJWzgLy7RT+josuojEW55rzt4iQxzluyd4zapl3K89xTfQpKxD8ppTSRko83wMh8JWP72mUkghtoKWJLyWGaRKMSAIhE40gly0zMTbN6NgIp06e5vTx42Tm06QCAW645gq27dhBe3s70VCIeMDg+ssuY/X2HQyc6UdoxfXXXcXFl17MnXfewTf/7u/oam2lZ+NmDhw7xoHX9iGtAPOZ7FHLMHdLKZtj0SjXXXr5v3bQGgUywHuAtWfD9reaC3o7Vriuzjw8MbM+HApFtdav1pUcKogmw3BLruJdaBUWZ9MLtQNWjbym0b6PVjU+j/Y0Gr9WJ5ASDwNlA/gYwkAY4DpVKuUsPUuXcPmll3Hh+VtxHY+R4WG+fedtiFCEmeFh6usTXHnFlXzvO99j7NRpfvVDt7L18svpnxzHTmdYumoVjvSnq/Pzv51KpZqA1cCr/8ZrbgCmgAeA9wH/uPjzz1cDhJS4thMxg8FpKxZ7LdjYeDwaCRENSCdqmS9L5U9IoZFCI9+0q6TUeL6Lbdu4dpXWpiYc18OtOviei+e6FMsl8vkcbsUmGoqSSqbo6Gwn1dnOgWPHsYArr7ySDZs2IIBIPEk0aNGUqieWSJEvlzhz5jjvuHB75YpbbmQqm0YVq5y79XyCkfC863u//au/9rFngDPACsD6V17TAi4A6oA9i37hi8CynzsA2XSBbJa8U7GnLcMMG6ZVCoQjWJFoPhgOnxHSfwGkUspAU2M8I9Ti6VfjKJ+AVpy/eSOty5fgK4NKxSFfKOFUqiRCQXpXruB9H3gf3V3dxJJ1+BWPpR1dXLjjQkZHR7nj7rtYKOZZtXoN+WKe+miIa7dd6LQ0t6QT4fBLIiA/cfjIsT35hVl91VVX0LNqxZjve79x+/t/6/aJyYk3zEvdopP916xIHGgEGoC7gT6g5ecOQD5fJmD5XDNuY2ktQlqXlK+wfe9UVespH30YRFYvBuzyjRFkQoKQi0OeJKuWL2PbJRfhoPA8l2QySXfPUupbmmjuaGPbju14rkMhnWbDylWs2bIZJSBfKHHe1vO4+sp3MDs/z9DQKAN9x18NB8xPXXLxxY9/6X9+9Ytf/t7376iLJ79yyfYd/e3dnX3xWPQTt9x0892/fMdX6WjvYDG0LAJL/hW7XgUOAS6QWvz5q8ArvxBR0Lp165BWQApDdiCYtKtVv1wqyrG5BRVLJhtFxX4G191cGw202Bfg+4vjKWvlyCWdHbjChGqZls52fMOglM0xn57n3I0b+d3P/x4PPfwwhew8Le2dHDh5kv/6G5+mald46IEHeHnXLsYnp0BBSHuPT2fz79Vavw+4atF5NiqtJwXi9o995uMHPvvx/0L/wAC3vPOdb7zGp4E54K43O+A3gRFb3PETiwD82FnRt90JW5aFRivP9yf6LEOt8XwMw1T1iRQEYxm3unBSC7FZoFFKEQgEaO/qxnE8pqYnqIuGuXTbDpxQgFJugblsjuN9Jwj50NzcDFqwkF7g9cOHIb1A2naYGh7Csas8/vgTPPLwo3R3L+FTn3wXL7+8i9MHX9+6JhTsWTQVQ0AYGJZCDCulnH/+8j8BsHHDhjcLeO7fMEEsakjxraaifyYAaL2YsRdCrfQ1KxqbCZgm9x18jYhd9U1pvAz6A572xJpVa7n1Ax+gqamxNpto3+u8tms3mWKBM/0TzAwPYZkB6mMJErEY2XKRkZFRstksxfQCXckkwyOjjI8MMzM9TUd7Ox+49YNsO38br7z2KjMz89TFU5UuM1D9zPs+UP2f99z18o/YYyn/NQEWgZ7/zXz8FCbsvq0ANDQ043s2pYpNW2szTz31LHv37uHqq69JLV+6tC5ftocKFXtPa0PD/NXXXNl0/vnbOH3qNN/51rdI1af40C//MseOHmFhcpzzNm+kuqKXQCBA/+gwp0+dJr+QwbIsiqUS61b2opRi7LVXqJRsJianueiiizh44AC3f//7HOs7juM5rOpqL+xYs6FScGzWr19PX1/fv26fF1PdwL7FVMNPff1UAejo6MD3FUL5CK3oWbeWxsYmHrr3nmAiFo1IKfRVV13dcfftt1/77MMPDxZdb+j2++49/anf/70TgUig6W//9n8yPj6O6zmMjA6zdt1afusjv0L3iuW4yRQPP/wYO599iunxUbLpDChFuWoztzDP+lWr2X30MMWFDEEzwJ1338Wjjz7O2OgwhgBhmLSkkqw+d9OKfeOjF6D1gy2JKPaKFfT39/97rzaz+OcXGwDD8/FcV0jTiLLpxmIysiBz+fymy658x2c/9isf6RFC7gJSa9atu/Ghe+68/fYHHn6mtb3j2s4lHdG77rqLkZFhhJSEQiEu276NG66/Dt/zeWHfAV5+7VWOHjxIbiGNZ9eK71rXRhzPTE1z8yWX8drpUxjCwAxajI+NonyIxCMYVoCgEWBpRycloUMzo+OXJM3o48FowDENk9aubkytiTgeniEZnJqo5RduvIHWlmYaGhqp2jaRUAhLCrauX4/Wmv3/hvb8TAB46KGHuPnmm/nGN77BBz7wAbK5HCuWL7daWpr+0DjwwOtzq9dXP/mJj38tHo0uOXpw/+jf/Pn/uP2Tn/3ttlMn+t7bPzh0SWtX97cq5dLlx4/3Nc/NzuBrj56updx0w02ct2UrO3ft5tFHHiZkBWlsb8M0JY5n16ZhLvaSKeWxMDtDQ3dHbcqWaYDUBEyDkBlGmiaGYRAJhzGM2nljIVv4hGNVJg/tH/rrFSt70b6ypGEEdLlYkt1ddJkGn/9/foe+48f52Md+nVtuuSW4rKdnBYIkCEfDSYQo/jQ2rfyPONcbb7wRgPHx8aDneW3Lly3b+Oq+fWsJBTdXEP+Unpv5WlN9/RIh4J4f/GAyYAWNF1944fN33HZbQzAaW6M071eO0+y7HjfffDO/8su/zG/+xm+ykE7zR1/4Y5557Aka6+ro6VlKyLQASTAcRghBPBohHA+jpSBfKGCGw5QcB1MKJALDtDAtE9MQBC0LX7nEkkmECOAIK5poav3N1d1dV5arpYiH/1+LxcJDjjCuLQ6PEfY13/7n7+K6bjgajbz3jh/84Ovnbt58teM4IIUjpPT4KY24lz9RVKP1m6OAzZ/93Gf/Qil1z9TU1A96urq/8Z8//p+Wh0KROs91llQdG7tULsRj8R/ccMu7P3r//fde9tzu3fQPjySS4YCoq0uyZ+9eentXct6W87jrrru4/c47GB4fo1wu4bs+c3Np1ra386W/+DOufOctaCmpVmwq5SoIqFYdPN+nmC/WZsxpQQCzVlM2JL7yiYbDJFIpPANc5TI0OtFdzOe/1Nre/pmm1uart5y39crmtubrp8uFhDTkDXPz81fOLqS/FQlHvnLjO9+5/p777x+59dZb9wg4gtZVfoxE29tpgjqBzUKIRuC9TY1Nw7Zt/+Vjjz5q3nX3vb9x8cUXLb/mkssYGB0mm8+z47zzsnsOH1lZLJUu3nbBdnfLOVuN1rZW4rEo99xzLw8++CCf+9znsO0q5VIFS0i0FDi2QzKWoL1nKQpNU12KLRs38NLDD1MslmuzQbXGNI0aRcV20Qr8xcsdfGoDWa2ARSIZJxqLMZnLUa3YlMplzu1dUbdkw5b3z6RnV37iQx/GyecvvO3uez968ljf5+ti8fjalavjkVDoYDgUGgLWfOGLf2J84Yt/4v80L3j4SQFYu5hwGgK+Cex0XbecrK/n7rvv3Lty9eovn3Pe1ve/vGcPM1PTlMrlpq9/4+vvHBufbApaRghDMjQyxPDQMAcPHERKg3Q6ffZWDI3G0CC1IpWqo7tnGWMjg7x+4BCXXLidPeefx5NPPY2UJnWJJDsuupBIKIxp1uZ/GgYo7aNdRcwKEYtEaGluIRyNoaZnMEwLX2jmK8WeoeeeJVVfRzAQqF717ve42YXce0+fOPFkPJl818a1a7ITo6OfPWfr1jrgmsUTb+4XIQrKLx65/wV47I0T75WXX85LL++aXr6s59GHH330PfOFrDE+Msze114LfeGLX+x2HVcI+cYFDbUuScNYHPAq3rCGPhqBj8DRmqCE5vp69h0/yd//47doaWvlY7/2MerrG4jFYmzdsoXe3l5GxkaZnJur0TZ8D0wLKxQkHIuSisVpaW1nNpvBq5ZJNaeYLOWYmJnD8Tya6lNoTWBgcGC5DFqB+paWlZvP2RwfHh4qf/XrX7vyM6dPhn77t3+nwbSsup82AD+pE55fTFKdPZwEg0GAyMUX7bimvb39mtHRsSPK85ibmSEajREMhASGgSCA1BamMDDMxbHS1LKgNR9j1jid1KacWMIkGguxkJ9janKEf/rWP1G1bT7ykY9wyaWXsP/gYb74B3/Abf/yPbJTcxgIIpEYkWiUUChIwArQ1bUEKxRibGoc7Tm1udIKlKsQWtHW2oI0DDk5OdUkA1YyGAk3L+9Zaj3x9FNGuVz9nWeeffZz46OjPUD9j1toebs1YGHxeN60+HM9cAVwyWJK9vGndu78ZwzzjvT8QnMyHqetvZUzp08jpHk2hNSiNrPB1woT5pUQCYEOvMHrlsInlohR8muDMDTw+iuvcfrkKeLxOPl8jkw6S8Q06Vm1GuU5hGMRAsEISoCJIB6O0d2xhE3btjKZnmF2bAq74lK7QaDGtGtpbQWtGR+fwPM9VqxYTkDKybnJiU/5nio1NrdckEylLvp38kE/Uw2oAg5w6SI/5q8WKRovAJ99bf/+2w7s2f2CNs2/7jvTX5mfn2P16jWLgYNCC7/G/9W1AdsWwo1o/ae+YT7Mm64uMQ2DcCRMOpelXKwAEmlALpNhbGSEXCaLFIKKdkln55FSYBoWplmbTS0x8WwbIyDoXtLNzdffRCKVolws1XijsnYuCAVCeL7PmTNn6Orq4rqrr+HFF3eGc5nM1oaGpH/n7Xf8faq+fmYx5/8LcRJuB1qBdYt/3wu8/EZG8PwtW4g0NyklxFdKtrNmcHjkoytX9CKFcXYQwRtCXlTnomlahzFow9X4gIHCEiZSBskW8qhqBaE1Siq0AcKvURWj0TDr1qzmvPO2sW/ffibGRhH4IA0qts1CzkMGLU4NnKZSKnP9dddy4NBBCJisXb+RUyMj1Kfq0MDgyDAXehcyPjnB0YOHAm0NzX5dc/Pg4nvlgNTp/jN897vf4bO/9ZuA4O++8pWfCwC5RftfBP6YGin1R5JYkeYmlK/saqn01YEzg1dt2ryh0zDeuB1JnGU6yxrJNlkU4psC1YwESa0uHAwEicajjM/PU61UkNrAVwKUh0azavUqfvnDv0RzUyMnT55memYGx3XArvUTWBg0NTSjgMmxKR5+5FFuvvFGfv+/fAavUub45BiB+jgrVq9Gac2Jkyf46y/9NdlcmkzFjpjC+rTh+Mtvvu76v3n4icfTQFxSlZVKJZ7O5wq5XF5deskONm86F8fz6O8f4jt33s4tV13D6wdef9ud8NOLnMjsmwUvhKCzdyWtTS1ErAAt3d1HDhw7+tLtd9yOp31UrfrLG5foGCiuueIy2dG7bLWs2vW1gR21Ar1hSBzfpiGZYN3qNSgp6IzHue7a66hrbeL8LVtobWvlm1//Gg899CB1qTquve566lLNeK5HMpVCRkMsZNLMzc1jO1W063DV9dez5YorSOfy7N9/gL5jR9FKobXPgUMHGZ2YxPZ8oZTbcO311/xS9/rV9z10333bHdc1/u4fv/cJrdRT3Y0tH4w0pSzLtHqklOf4nn8e6Obnn37mLZW5/iO5oGEguliGKwoh6FnRg1aaloYUr+x9hURTy0qjWr7VC4WvnJucXSw56sUu9RrLeePK1aw/ZzOtq1fxkiEZPnWGaCRKuWrT27ucq2+4gVhDIz2t7fQdO0ZXUwOf/thHuXL2egwlqFaqNCVS3Piud2FZAQZOD1Atl7GsIFVHMTo0xvKelVx89SVcc+VlNDS1cODoMeLxGCYCp1xanC8dob2lndGRsdqhzvO4YN06rr7peobSc8saE8nu+x9/rEHa9AZMKxmvr//zgVf2vq84P7fJdv36Urm8YBqBT/7PL/31M6Z8Gwsyb8qRTy9u5VZgrK1zCZ6nEQECUsgdm87delPQCrzLKRZ67GIRKUFosRhygsZECJ/21gZW9i7nyp4etl96Ed/57ve5fOt5mFKyfs1q6htbODnQz57du/Fsh7r6FL7rsm3dBlLNzZSrNk0NDTz65JM889RTuI5DIBBAaU2xkKauvoHm5hbaWlrpHxjgwcee4tiJ46zsXcY7r7sR7WuiySRWMMCynmX0HTuG5/lEDMk555zLwOQYPfVtdK1eZ0bq57a+euAgM2PjPLdnd/fwmf5u5SlGp2fTaP9Pi7n8c/F4ktUrV/5MNCANFBaL1a9LAU5JmWEtPh80xOeXrV8bt7VHZtbFqdooz0ctXpagEAgt8YXmiZf2cnxglA+9711cePVV/NanP01Ig6E10WCAkdFRHnn6aZ5/8UU0ghcPH2PsC19k+/nn84GPfARhBdizZy9PPvc8xUyBiy7aTr6QJ5dOs6SnHSuWwAhKdr26hx9857usX7OGbCbNqzvH2LphE8FIjL5jxzlv8zm0t7fRvWQpA4MDNDfWE29qQnsQjEcRnkesLsXo1BTzgwPYjoNSHlowjta/fV/uxrvfW/cYUkte3//6zwSA8iL5aDmAqzSu4W9vMMOfu+bSi+P1K9dSVj5TdQlmJ6fJpjM1B6neuPXRAyQegjNjY3z5n74NZpBbf/WjlD2P08dPcPR4H0tXraa1rRNErUfM9mxODJzh+JkzONLg0u0XMjo6TEdrE9d9+CM0NjVw6shhkh3NjE5M0HfkBB2tXXSuXcPFOy5iPDOPrNqs37iJJ57fyeEjh5kenyA3N8/C3BxVzyVsBamvb8DxXHq7umlqacORkpd3vYhZzLNx03pGZueYGBs/qm37swr13LvrHkULQSGb+ZnVA9SiH9gAWLlCUUZDwU9KoVOlqo07PsKmVStZ0t7J4OAQZ/pPMz8zhVN10H7tHCC1xjQtmptbufLKK1lz7hYOHDhAfX19baQ9mopSvL7vNZxKCUMKtDYQWuNpzdzCAl3dXdz6S79ELBwhlapnamKcbedv5dWBk+x9fT+2bVMpVyhWqrz08ssELZNLL7qIcHMTjz+7k+HBIYTn89reV2jpbMNzHDpbmzj33HNYu24ddfWNuFLyyoGD7H72KVKJOBXXZXZ25rGyXf18KBg8bjguWmlK+beepTB+Esl/4Qtf4E0n4IuBZ/7kL/+iMSDFf0N59fO5NAEpqYvVkUykiMZjKCkolkpUy9VF9nDtXq/LLrmEz3z2M2zavImBwUG+/NWv4jku5517LlYgQDRZR7Iuia990tkM1UplMX/hEwxZ7Dh/G9su3EE4mWB+IU2mkGd0bAzf9ujt7eXYmdPYxVojxumTJ1i+tAc3HODQsaOcPHIMp1LBsizaO9ooV6ukIiGuv+JKrrz6Opb1rsYPhXl+715efPpxlGdTrLj56amZvz14YN/no9HYaGl6GsMyKf6EV1n9RBrwJkc8sHgiTrq57DD1Df+17Kg/HJucPdfzIJ3O0tbeQSQWJRWPkognKSxk8VwXUwCGQSQWoZDP89JLL/LIo48yNztL74oVpOfmMXyfeCzGRVu3sWX9Jk4PD7Frz2527XyBhclJjved5N7vfZcjY4M88fAjFDM51ixdwcWXXU68oZ6jfUdZ1tZG34mTDPYP4Do+fadOkz9ymHw2h/L8Wh8BmvTCAsl4jIvPO5/rb7yBzpWrKWrN4888yZE9u7G0wFXqgOOrP3n6lVce7W1v903TILew8BNfYfUTa8CbtKAAnATGupctc5565umTSvGk6/qqUCqsSqcXIsVMjkI+Tz5bIJPOUCgU8DyPZDxENBrn5ImTvPjSi+zft59KsYwWEIqG2XTOObzy/POsWLYUGQoSMA3C9SlGx8Y4dbyPQiGH57m0xhNsv+QSujs6uf76G2lbvoIDRw8j8nlWLlvKpZdfzpYLzmdpVyeJ1k76TveRmZtDLF7hKoUkGq0NoVq3upebrr2Rjt5eslWHR598khMHD4JnL/i+/03Pk59TvvdaKpHQ0XicA7v3ojyP/8j6jwKggFnA7VmyhL/8wXewqk4O7TzrKV6p2NVUoVRcmknnzfRClnwxi+PY+Iuzm2PxGGWnSqVcPnulrQSUr7jo4os5cPgwEydPsX7TRgpovnf77Tx02+10NzfS0NKGKSQXnb+dZWvWUPJ8HnnySf7529/i9OGjmFLRUJ8iGqujvq6OlatWMl+p8vKzz6JdF73Y2hqNxqlP1tHb3cl7330Lq7dsZWR2hqeffZaR/jNVz64+VnLsz056499OGnXZjqzCaG3g8fvv++kQmH/ayaVUQ/1igx0o3CjKuE6g/xOIi0CFlNK1Rmrl0VRfT0VDLptdvMOxlhsyjSCf/93fYTY9xyuPPcnv/4//wX27XuLB734f4Th0dXfQ2bOUhniK7dt20DcyzMjYANmFNJPjE8xMT6OVTyQUpD7ZRH19ilRzisHJGUbPDNTujJSaaChEa0szvUuX8J53vZula9dz6MwZDu17vZqbn9slUP9QdNwnouFQyVG1ttl7b7v3pyqvt4UbmmxMIlwNxhs35jkJqc2rBPqXteZSAUmlfbpbWkh1dHCk7zjSdpGLM5mV0nzwfe/jkh07uOeuO8l5LqePn6ZcztVGXipQUtMSibPt8kvZs38/brWC8jR21cX3qmevJ9ZCYCiN0j5KKUKBEKnGesKhKBEjwLrVK7juhusJNzSx78jh3JlTx14s5kv/4pSLzzQ2t+Rt2yUQqLVAPf3YY7/YvKCzmbr5WjgWDoSJNoeQRZkXgvsExuOgt6L992gtrkHrFY2pejMSjVGx04vXjAsUHqcHznDFFVcwNDnF8PAglrQQWLVrDEUtkRcOBrF9TXp2rkboXTxhIGrzQaUy8IXC14qwZbFp1Rre/Z73Em1rYdcrrxBXggsvvtBTwWD/viN9Tx3Yd+C+/NzIvvrWpRUrEGQmmyYuTG6/6+63jT34tlITK06FyniFWCBGKBXErToVNC/n8vmXo5G6zmLJ3jE6OnqNXa5s97Reanp+CA0Sg4mJCVzPobWlieGhocXijcYMGLi+Qns+kXCYmfk5tOcjF5u2tVic+OkLkD71iQQb1qxl1Zo1dHd2YwdMTuzeU71w9brhzedfsHeynH1q995du//8978w/sFf/TW02wCGRVgoHn3oibebOvv209P/1xWNJdFopBI0pxIMTozJaCLZJqXaIJXappTYgpArLcts/b3f+2+xE8ePyzvvuptIKMia1auwhcHU1CTp6Vm2b9iAbG/h5aefrY2b1LXD3Rs3pC/r6GD7jotV2bOLJ/rPTI8ODp/e2L10/2f/86deuf5XPnIUwdRTLzyvXjvwOplsgVg8hlG233zOeduX+bMGoFSsmad4PMhCNUxdQ6PyfX8C1IRlmk+6th9E0lgulbtWr17zkfbWts33P3D/aStgNF++ZVu939YWu/0734q0tLYGfLQxOzmFJQxfoRwBZS1kES3SAjWdy+ZHn9z5/MD4xMSA79ijyUBgfral2S6UihTn58hEwly87UIalvRw3rJl/DyWyc9pFQr2YkK1tkKhELbShAKWLRATv/v//O7EDTfckALcG2666Q+TyaStq3ZozeqVYWUSWF7fajnSl6dOnCTiKaUs4YJ2PHQlYASqxVyj29lk6zIQjUYwomFMQE7N8kdf+GM++OlP8YuwTH5BVnVxvLvj2G9mHaSBRCKRiB08dLBw11f/3slmc3lYHBZi1sbba7v0IzZVKZ9QZJrsdAhfKPLlHybI5vj/11uhQG7SWt+mte79aVJBfpGW/AV/vsJi3dn4/7fkz0cDTK31Cq116P9WDRC/yAD8n7Kw/7et/xfjsaxrAlEhDwAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAyMC0wOC0wNVQyMjoxMjozMCswMDowMLWi35kAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMjAtMDgtMDVUMjI6MTI6MzArMDA6MDDE/2clAAAAAElFTkSuQmCC", 0);
        ((TextView) new AlertDialog.Builder(this).setIcon(new BitmapDrawable(getResources(), BitmapFactory.decodeByteArray(arrayOfByte, 0, arrayOfByte.length))).setTitle("  PROJECTXTEAM").setCancelable(false).setMessage(Html.fromHtml("<p>PARA COMPRAR O MOD OU RENOVAR ENTRE EM CONTATO PELO DISCORD:  <p> <a href=\"https://discord.gg/ftMyqyyk35\"> * CLIQUE AQUI *<p></a></p>")).setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Activity2.this.Login();
            }
        }).show().findViewById(16908299)).setMovementMethod(LinkMovementMethod.getInstance());
    }

    @SuppressLint({"SetTextI18n", "WrongConstant", "ClickableViewAccessibility"})
    public void Login() {
        stopService(new Intent(this, Flutuante.class));
        this.prefs = Prefs.with(this);
        SharedPreferences sharedPreferences = getSharedPreferences("SavePref", 0);
        String struser = sharedPreferences.getString("User", (String) null);
        String strpass = sharedPreferences.getString("Pass", (String) null);
        Boolean rememberMe = Boolean.valueOf(sharedPreferences.getBoolean("RememberMe", false));
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(Color.parseColor("#ffffff"));
        linearLayout.setPadding(4, 4, 4, 4);
        EditText editTextUser = new EditText(this);
        if (struser != null && !struser.isEmpty()) {
            editTextUser.setText(this.prefs.read("USER_Sv", ""));
        }
        editTextUser.setHintTextColor(Color.parseColor("#7a7a7a"));
        editTextUser.setTextColor(Color.parseColor("#000000"));
        editTextUser.setHint("Usuário");
        final EditText editTextPass = new EditText(this);
        if (strpass != null && !strpass.isEmpty()) {
            editTextPass.setText(this.prefs.read("PASS_Sv", ""));
        }
        editTextPass.setHintTextColor(Color.parseColor("#7a7a7a"));
        editTextPass.setTextColor(Color.parseColor("#000000"));
        editTextPass.setHint("Senha");
        editTextPass.setInputType(129);
        CheckBox checkSaveLogin = new CheckBox(this);
        checkSaveLogin.setPadding(5, 5, 0, 5);
        checkSaveLogin.setTextSize(15.0f);
        checkSaveLogin.setChecked(rememberMe.booleanValue());
        checkSaveLogin.setTextColor(Color.parseColor("#000000"));
        checkSaveLogin.setText("Lembrar");
        final Button btnLogin = new Button(this);
        btnLogin.setBackgroundColor(Color.parseColor("#000000"));
        btnLogin.setTextColor(Color.rgb(255, 255, 255));
        btnLogin.setText("Ｌｏｇｉｎ");
        CheckBox mtLogin = new CheckBox(this);
        mtLogin.setPadding(0, 5, 5, 5);
        mtLogin.setTextSize(15.0f);
        mtLogin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    editTextPass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    editTextPass.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });
        mtLogin.setTextColor(Color.parseColor("#000000"));
        mtLogin.setText("Mostrar Senha");
        linearLayout.addView(editTextUser);
        linearLayout.addView(editTextPass);
        linearLayout.addView(checkSaveLogin);
        linearLayout.addView(mtLogin);
        linearLayout.addView(btnLogin);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        TextView title = new TextView(this);
        title.setText("ＰＲＯＪＥＣＴＸＴＥＡＭ");
        title.setPadding(0, 20, 0, 20);
        title.setTextColor(Color.rgb(255, 255, 255));
        title.setGravity(1);
        title.setTextSize(20.0f);
        title.setTypeface((Typeface) null, 1);
        title.setBackgroundColor(Color.parseColor("#000000"));
        builder.setCustomTitle(title);
        builder.setCancelable(true);
        builder.setView(linearLayout);
        AlertDialog show = builder.show();
        TextView textView = title;
        final EditText editText3 = editTextUser;
        AlertDialog.Builder builder2 = builder;
        final EditText editText4 = editTextPass;
        final CheckBox checkSaveLogin2 = checkSaveLogin;
        AlertDialog alertDialog = show;
        show.setCancelable(true);
        btnLogin.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == 1) {
                    btnLogin.setBackgroundColor(Color.parseColor("#000000"));
                    return false;
                } else if (motionEvent.getAction() != 0) {
                    return false;
                } else {
                    btnLogin.setBackgroundColor(Color.parseColor("#000000"));
                    return false;
                }
            }
        });
    //    C00765 r17 = r0;
        AlertDialog alertDialog2 = show;
        CheckBox checkBox = mtLogin;
        final SharedPreferences sharedPreferences2 = sharedPreferences;
        OnClickListener r0 = new View.OnClickListener() {
            public void onClick(View view) {
                String user = editText3.getText().toString().trim();
                String pass = editText4.getText().toString().trim();
                Activity2.this.prefs.write("USER_Sv", user);
                Activity2.this.prefs.write("PASS_Sv", pass);
                boolean isChecked = checkSaveLogin2.isChecked();
                SharedPreferences.Editor edit = sharedPreferences2.edit();
                if (isChecked) {
                    edit.putString("User", user);
                    edit.putString("Pass", pass);
                } else {
                    edit.clear();
                }
                edit.putBoolean("RememberMe", isChecked);
                edit.apply();
                new Auth(Activity2.this).execute(new String[]{user, pass, Activity2.rdStr()});
            }
        };
        btnLogin.setOnClickListener(r0);
    }

    public static String rdStr() {
        return UUID.randomUUID().toString().replace("-", "");
    }
}
