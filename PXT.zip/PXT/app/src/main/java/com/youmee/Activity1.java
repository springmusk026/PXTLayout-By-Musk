package com.youmee;

import android.content.Context;
import android.content.Intent;

public class Activity1 {
    public static void Loading(Context ctx) {
        try {
            ctx.startActivity(new Intent(ctx, Class.forName("com.youmee.Activity2")));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
