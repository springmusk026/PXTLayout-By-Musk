package com.youmee;

import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Utils {
    public static String bytesToHex(byte[] bytes) {
        char[] hexArray = "0123456789abcdef".toCharArray();
        char[] hexChars = new char[(bytes.length * 2)];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 255;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[(j * 2) + 1] = hexArray[v & 15];
        }
        return new String(hexChars);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:?, code lost:
        r1.close();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String readStream(java.io.InputStream r5) {
        /*
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.io.BufferedReader r1 = new java.io.BufferedReader     // Catch:{ IOException -> 0x0034 }
            java.io.InputStreamReader r2 = new java.io.InputStreamReader     // Catch:{ IOException -> 0x0034 }
            r2.<init>(r5)     // Catch:{ IOException -> 0x0034 }
            r1.<init>(r2)     // Catch:{ IOException -> 0x0034 }
            r2 = 0
            java.lang.String r3 = ""
        L_0x0012:
            java.lang.String r4 = r1.readLine()     // Catch:{ Throwable -> 0x0023 }
            r3 = r4
            if (r4 == 0) goto L_0x001d
            r0.append(r3)     // Catch:{ Throwable -> 0x0023 }
            goto L_0x0012
        L_0x001d:
            r1.close()     // Catch:{ IOException -> 0x0034 }
            goto L_0x0035
        L_0x0021:
            r3 = move-exception
            goto L_0x0025
        L_0x0023:
            r2 = move-exception
            throw r2     // Catch:{ all -> 0x0021 }
        L_0x0025:
            if (r2 == 0) goto L_0x0030
            r1.close()     // Catch:{ Throwable -> 0x002b }
            goto L_0x0033
        L_0x002b:
            r4 = move-exception
            r2.addSuppressed(r4)     // Catch:{ IOException -> 0x0034 }
            goto L_0x0033
        L_0x0030:
            r1.close()     // Catch:{ IOException -> 0x0034 }
        L_0x0033:
            throw r3     // Catch:{ IOException -> 0x0034 }
        L_0x0034:
            r1 = move-exception
        L_0x0035:
            java.lang.String r1 = r0.toString()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.youmee.Utils.readStream(java.io.InputStream):java.lang.String");
    }

    public static String SHA256(String data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.reset();
            md.update(data.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(md.digest()).toUpperCase();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    public static String profileDecrypt(String data, String sign) {
        char[] key = sign.toCharArray();
        char[] out = fromBase64String(data).toCharArray();
        for (int i = 0; i < out.length; i++) {
            out[i] = (char) (key[i % key.length] ^ out[i]);
        }
        return new String(out);
    }

    public static String toBase64(String s) {
        return Base64.encodeToString(s.getBytes(StandardCharsets.UTF_8), 2);
    }

    public static String toBase64(byte[] s) {
        return Base64.encodeToString(s, 2);
    }

    public static byte[] fromBase64(String s) {
        return Base64.decode(s, 2);
    }

    public static String fromBase64String(String s) {
        return new String(Base64.decode(s, 2), StandardCharsets.UTF_8);
    }
}
