package com.youmee;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.Html;
import android.util.Base64;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.youmee.Flutuante;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import javax.net.ssl.TrustManagerFactory;
import org.json.JSONObject;

public class Flutuante extends Service {
    public static boolean isRunning = false;
    public Button close;
    public WindowManager.LayoutParams espParams;
    public Button kill;
    public LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    public View mFloatingView;
    public RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public ESPView overlayView;
    public WindowManager.LayoutParams params;
    public LinearLayout patches;
    public Prefs prefs;
    public FrameLayout rootFrame;
    public ImageView startimage;
    public Timer timer;
    public LinearLayout view1;
    public LinearLayout view2;

    private interface InterfaceBtn {
    }

    /* renamed from: com.youmee.Flutuante$SB */
    private interface C0093SB {
        void OnWrite(int i);
    }

    /* renamed from: com.youmee.Flutuante$SW */
    private interface C0094SW {
        void OnWrite(boolean z);
    }

    public static native void CheckStatus();

   public static native void DrawOn(ESPView eSPView, Canvas canvas);

  /*  public static native String En01();

    public static native String En02();

    public static native String En03();

    public static native String En04();

    public static native String En05();

    public static native String En06();

    public static native String En07();

    public static native String En08();

    public static native String En09();

    public static native String En10();

    public static native String En11();

    public static native String En12();

    public static native String En13();

    public static native String En14();

    public static native String En15();

    public static native String En16();

    public static native String En17();

    public static native String En18();

    public static native String En19();

    public static native String En20();

    public static native String En21();

    public static native String En22();

    public static native String En23();

    public static native String En24();
*/
      public static native int dmNiY3h4Ym54();

    
    
	public static native String a2hsamhvb3A();

	
	public static native String Y2hpcnNvYXI();

	public static native String[] getListFT();
	
    public void onCreate() {
        super.onCreate();
        System.loadLibrary("PxtPxt");
    //    this.timer = new Timer();
      this.overlayView = new ESPView(getBaseContext());
       this.overlayView = new ESPView(this);
        TGFydW5zYWQ();
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            public void run() {
                Flutuante.this.Thread();
                handler.postDelayed(this, 1000);
            }
        });
    }

    public void stackOverflow() {
        stackOverflow();
    }

    public final void Thread() {
    //    vpn();
        if (this.mFloatingView == null) {
            return;
        }
        if (isChayNgam()) {
            this.mFloatingView.setVisibility(4);
        } else {
            this.mFloatingView.setVisibility(0);
        }
    }

    public final boolean isChayNgam() {
        ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
        int i = Build.VERSION.SDK_INT;
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    public final int getLayoutType() {
        int i = Build.VERSION.SDK_INT;
        if (i >= 26) {
            return 2038;
        }
        if (i >= 24) {
            return 2002;
        }
        if (i >= 23) {
            return 2005;
        }
        return 2003;
    }

    public final void DrawCanvas() {
        this.espParams = new WindowManager.LayoutParams(-1, -1, getLayoutType(), 56, -3);
        WindowManager.LayoutParams layoutParams = this.espParams;
        layoutParams.gravity = 8388659;
        layoutParams.x = 0;
        layoutParams.y = 0;
        this.mWindowManager.addView(this.overlayView, layoutParams);
    }

    @SuppressLint({"SetTextI18n", "ClickableViewAccessibility"})
    public final void TGFydW5zYWQ() {
       // vpn();
        this.prefs = Prefs.with(this);
        Toast.makeText(getBaseContext(), "Admin: Tenha um bom jogo e divirta-se", 1).show();
        Toast toast = Toast.makeText(this, "ＰＲＯＪＥＣＴＸ ＴＥＡＭ", 1);
        TextView v = (TextView) toast.getView().findViewById(16908299);
        v.setTextColor(-65536);
        toast.show();
        this.rootFrame = new FrameLayout(getBaseContext());
        this.mRootContainer = new RelativeLayout(getBaseContext());
        this.mCollapsed = new RelativeLayout(getBaseContext());
        this.mExpanded = new LinearLayout(getBaseContext());
        this.view1 = new LinearLayout(getBaseContext());
        this.patches = new LinearLayout(getBaseContext());
        this.view2 = new LinearLayout(getBaseContext());
        this.mButtonPanel = new LinearLayout(getBaseContext());
        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout.setPadding(3, 3, 3, 3);
        relativeLayout.setVerticalGravity(16);
        this.kill = new Button(this);
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(mo2336dp(60), mo2336dp(60));
        layoutParams6.topMargin = mo2336dp(15);
        LinearLayout.LayoutParams layoutParams8 = new LinearLayout.LayoutParams(mo2336dp(30), mo2336dp(30));
        layoutParams8.leftMargin = mo2336dp(55);
        layoutParams8.topMargin = mo2336dp(10);
        this.kill.setBackgroundColor(-16777216);
        this.kill.setText(Html.fromHtml("<font face='sans-serif-black'><b> INVISÍVEL </b></font>"));
        this.kill.setTextSize(15.0f);
        this.kill.setTextColor(-1);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(11);
        this.close = new Button(this);
        this.close.setBackgroundColor(-16777216);
        this.close.setText(Html.fromHtml("<font face='sans-serif-black'><b> MINIMIZAR </b></font>"));
        this.close.setTextSize(15.0f);
        this.close.setTextColor(-1);
        this.close.setLayoutParams(layoutParams);
        relativeLayout.addView(this.kill);
        relativeLayout.addView(this.close);
        this.rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        this.mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        this.mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        this.mCollapsed.setVisibility(0);
        this.startimage = new ImageView(getBaseContext());
        this.startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int i = (int) TypedValue.applyDimension(1, (float) dmNiY3h4Ym54(), getResources().getDisplayMetrics());
        this.startimage.getLayoutParams().height = i;
        this.startimage.getLayoutParams().width = i;
        this.startimage.requestLayout();
        this.startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(a2hsamhvb3A(), 0);
        this.startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        this.startimage.setImageAlpha(200);
        ((ViewGroup.MarginLayoutParams) this.startimage.getLayoutParams()).topMargin = dp2px(10);
        this.mExpanded.setVisibility(8);
        this.mExpanded.setBackgroundColor(-16777216);
        this.mExpanded.setAlpha(0.95f);
        this.mExpanded.setOrientation(1);
        this.mExpanded.setLayoutParams(new LinearLayout.LayoutParams(mo2336dp(200), mo2336dp(-2)));
        LinearLayout linearLayout1 = new LinearLayout(this);
        linearLayout1.setLayoutParams(new LinearLayout.LayoutParams(-1, mo2336dp(30)));
        linearLayout1.setGravity(5);
        LinearLayout linearLayout12 = new LinearLayout(this);
        linearLayout12.setLayoutParams(new LinearLayout.LayoutParams(mo2336dp(200), -2));
        linearLayout12.setBackgroundColor(Color.parseColor("#292828"));
        linearLayout12.setOrientation(1);
        LinearLayout linearLayout4 = new LinearLayout(this);
        linearLayout4.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout4.setOrientation(0);
        Toast toast2 = toast;
        linearLayout4.setPadding(mo2336dp(8), mo2336dp(8), mo2336dp(8), mo2336dp(8));
        ScrollView scrollView = new ScrollView(getBaseContext());
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, mo2336dp(152)));
        LinearLayout linearLayout5 = new LinearLayout(this);
        linearLayout5.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout5.setOrientation(1);
        LinearLayout linearLayout = linearLayout5;
        new LinearLayout.LayoutParams(-2, mo2336dp(33)).rightMargin = mo2336dp(5);
        Color.parseColor("#ffffff");
        LinearLayout.LayoutParams layoutParams11 = new LinearLayout.LayoutParams(-1, mo2336dp(40));
        layoutParams11.topMargin = mo2336dp(5);
        layoutParams11.leftMargin = mo2336dp(5);
        layoutParams11.rightMargin = mo2336dp(5);
        LinearLayout.LayoutParams layoutParams12 = new LinearLayout.LayoutParams(-2, -2);
        LinearLayout.LayoutParams layoutParams2 = layoutParams11;
        layoutParams12.leftMargin = mo2336dp(5);
        layoutParams12.rightMargin = mo2336dp(5);
        TextView textView = v;
        int i2 = i;
        this.view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        this.view1.setBackgroundColor(-16777216);
        this.patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        this.patches.setOrientation(1);
        this.view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        this.view2.setBackgroundColor(-16777216);
        this.view2.setPadding(0, 0, 0, 10);
        this.mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        TextView textView2 = new TextView(getBaseContext());
        textView2.setText(Y2hpcnNvYXI());
        textView2.setTextColor(-1);
        textView2.setTypeface(Typeface.DEFAULT_BOLD);
        textView2.setTextSize(16.0f);
        textView2.setPadding(10, 10, 10, 5);
        LinearLayout.LayoutParams layoutParams99 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams99.gravity = 17;
        textView2.setLayoutParams(layoutParams99);
        LinearLayout.LayoutParams layoutParams3 = layoutParams99;
   //     int Exp = Integer.parseInt(this.prefs.read(En21(), ""));
    //    Calendar c = Calendar.getInstance();
       LinearLayout.LayoutParams layoutParams4 = layoutParams6;
    //    SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
      //  c.add(5, Exp);
   //     String end_date = df.format(c.getTime());
     //   int i3 = Exp;
        StringBuilder sb = new StringBuilder();
    //    Calendar calendar = c;
        sb.append("Expiração: ");
        sb.append("");
        String Expire = sb.toString();
  //      SimpleDateFormat simpleDateFormat = df;
        TextView textView22 = new TextView(getBaseContext());
        textView22.setText(Expire);
        textView22.setTextColor(-65536);
        textView22.setTypeface(Typeface.DEFAULT_BOLD);
        textView22.setTextSize(10.0f);
        String str = Expire;
        textView22.setPadding(10, 5, 10, 10);
        LinearLayout.LayoutParams layoutParams32 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams32.gravity = 17;
        textView22.setLayoutParams(layoutParams32);
        LinearLayout.LayoutParams layoutParams5 = layoutParams32;
        byte[] bArr = decode;
        new LinearLayout.LayoutParams(-1, mo2336dp(25)).topMargin = mo2336dp(2);
        this.rootFrame.addView(this.mRootContainer);
        this.mRootContainer.addView(this.mCollapsed);
        this.mRootContainer.addView(this.mExpanded);
        this.mCollapsed.addView(this.startimage);
        this.mExpanded.addView(textView2);
        this.mExpanded.addView(textView22);
        this.mExpanded.addView(this.view1);
        this.mExpanded.addView(scrollView);
        scrollView.addView(this.patches);
        this.mExpanded.addView(this.view2);
        this.mExpanded.addView(relativeLayout);
        this.mFloatingView = this.rootFrame;
        if (Build.VERSION.SDK_INT >= 26) {
            this.params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            this.params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams42 = this.params;
        layoutParams42.gravity = 51;
        layoutParams42.x = 0;
        layoutParams42.y = 100;
        this.mWindowManager = (WindowManager) getSystemService("window");
        DrawCanvas();
        ScrollView scrollView2 = scrollView;
        this.mWindowManager.addView(this.mFloatingView, this.params);
        RelativeLayout relativeLayout2 = this.mCollapsed;
        LinearLayout linearLayout2 = this.mExpanded;
        TextView textView3 = textView2;
        this.mFloatingView.setOnTouchListener(onTouchListener());
        this.startimage.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout2);
        RelativeLayout relativeLayout3 = relativeLayout2;
     	startServer();
		
    }

    public final View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            public final View collapsedView = Flutuante.this.mCollapsed;
            public final View expandedView = Flutuante.this.mExpanded;
            public float initialTouchX;
            public float initialTouchY;
            public int initialX;
            public int initialY;

            public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
                int action = param1MotionEvent.getAction();
                if (action == 0) {
                    this.initialX = Flutuante.this.params.x;
                    this.initialY = Flutuante.this.params.y;
                    this.initialTouchX = param1MotionEvent.getRawX();
                    this.initialTouchY = param1MotionEvent.getRawY();
                    return true;
                } else if (action == 1) {
                    int i = (int) (param1MotionEvent.getRawX() - this.initialTouchX);
                    int j = (int) (param1MotionEvent.getRawY() - this.initialTouchY);
                    if (i < 10 && j < 10 && Flutuante.this.isViewCollapsed()) {
                        this.collapsedView.setVisibility(8);
                        this.expandedView.setVisibility(0);
                    }
                    return true;
                } else if (action != 2) {
                    return false;
                } else {
                    Flutuante.this.params.x = this.initialX + ((int) (param1MotionEvent.getRawX() - this.initialTouchX));
                    Flutuante.this.params.y = this.initialY + ((int) (param1MotionEvent.getRawY() - this.initialTouchY));
                    Flutuante.this.mWindowManager.updateViewLayout(Flutuante.this.mFloatingView, Flutuante.this.params);
                    return true;
                }
            }
        };
    }

    public final boolean isViewCollapsed() {
        return this.mFloatingView == null || this.mCollapsed.getVisibility() == 0;
    }

    public final void initMenuButton(final View collapsedView, final View expandedView) {
        this.startimage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                collapsedView.setVisibility(8);
                expandedView.setVisibility(0);
            }
        });
        this.kill.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Flutuante.this.mCollapsed.setVisibility(0);
                Flutuante.this.mExpanded.setVisibility(8);
                Flutuante.this.mCollapsed.setAlpha(0.0f);
                WindowManager.LayoutParams layoutParams = Flutuante.this.params;
                layoutParams.gravity = 51;
                layoutParams.x = 0;
                layoutParams.y = 48;
                layoutParams.flags &= -8193;
                Flutuante.this.mWindowManager.updateViewLayout(Flutuante.this.rootFrame, Flutuante.this.params);
            }
        });
        this.close.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
             //   Flutuante.this.vpn();
                collapsedView.setVisibility(0);
                expandedView.setVisibility(8);
                Flutuante.this.mCollapsed.setAlpha(1.0f);
            }
        });
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

  /*  class DRM extends TimerTask {
        public final String PASS = Flutuante.En20();
        public final String USER = Flutuante.En19();
        public byte[] crt = {45, 45, 45, 45, 45, 66, 69, 71, 73, 78, 32, 67, 69, 82, 84, 73, 70, 73, 67, 65, 84, 69, 45, 45, 45, 45, 45, 13, 10, 77, 73, 73, 70, 54, 122, 67, 67, 66, 78, 79, 103, 65, 119, 73, 66, 65, 103, 73, 82, 65, 73, 68, 53, 88, 53, 112, 118, 85, 72, 71, 112, 43, 81, 49, 84, 54, 88, 103, 117, 67, 78, 81, 119, 68, 81, 89, 74, 75, 111, 90, 73, 104, 118, 99, 78, 65, 81, 69, 76, 66, 81, 65, 119, 13, 10, 99, 106, 69, 76, 77, 65, 107, 71, 65, 49, 85, 69, 66, 104, 77, 67, 86, 86, 77, 120, 67, 122, 65, 74, 66, 103, 78, 86, 66, 65, 103, 84, 65, 108, 82, 89, 77, 82, 65, 119, 68, 103, 89, 68, 86, 81, 81, 72, 69, 119, 100, 73, 98, 51, 86, 122, 100, 71, 57, 117, 77, 82, 85, 119, 13, 10, 69, 119, 89, 68, 86, 81, 81, 75, 69, 119, 120, 106, 85, 71, 70, 117, 90, 87, 119, 115, 73, 69, 108, 117, 89, 121, 52, 120, 76, 84, 65, 114, 66, 103, 78, 86, 66, 65, 77, 84, 74, 71, 78, 81, 89, 87, 53, 108, 98, 67, 119, 103, 83, 87, 53, 106, 76, 105, 66, 68, 90, 88, 74, 48, 13, 10, 97, 87, 90, 112, 89, 50, 70, 48, 97, 87, 57, 117, 73, 69, 70, 49, 100, 71, 104, 118, 99, 109, 108, 48, 101, 84, 65, 101, 70, 119, 48, 120, 79, 84, 65, 51, 77, 68, 77, 119, 77, 68, 65, 119, 77, 68, 66, 97, 70, 119, 48, 120, 79, 84, 69, 119, 77, 68, 69, 121, 77, 122, 85, 53, 13, 10, 78, 84, 108, 97, 77, 66, 77, 120, 69, 84, 65, 80, 66, 103, 78, 86, 66, 65, 77, 84, 67, 71, 116, 116, 98, 50, 82, 122, 76, 109, 49, 115, 77, 73, 73, 66, 73, 106, 65, 78, 66, 103, 107, 113, 104, 107, 105, 71, 57, 119, 48, 66, 65, 81, 69, 70, 65, 65, 79, 67, 65, 81, 56, 65, 13, 10, 77, 73, 73, 66, 67, 103, 75, 67, 65, 81, 69, 65, 113, 68, 77, 48, 52, 103, 116, 121, 106, 80, 76, 114, 117, 97, 113, 103, 70, 84, 56, 71, 99, 49, 112, 103, 68, 48, 77, 49, 71, 78, 49, 86, 43, 49, 78, 56, 89, 102, 76, 50, 89, 65, 98, 48, 105, 100, 118, 48, 100, 87, 108, 116, 13, 10, 66, 106, 43, 116, 49, 100, 117, 82, 111, 80, 52, 55, 89, 43, 98, 81, 65, 69, 104, 79, 67, 43, 47, 110, 108, 97, 88, 113, 115, 115, 85, 65, 101, 116, 72, 68, 67, 69, 89, 100, 79, 54, 117, 110, 109, 88, 71, 113, 48, 82, 75, 119, 53, 114, 79, 80, 77, 103, 65, 113, 99, 81, 79, 48, 13, 10, 50, 86, 81, 85, 80, 86, 56, 120, 53, 119, 85, 111, 121, 85, 52, 76, 115, 121, 54, 98, 79, 57, 86, 48, 68, 83, 72, 120, 89, 77, 114, 71, 43, 97, 107, 83, 65, 56, 121, 73, 82, 87, 104, 77, 81, 84, 115, 51, 105, 109, 118, 78, 111, 73, 78, 83, 90, 111, 111, 70, 72, 110, 75, 100, 13, 10, 115, 83, 76, 68, 79, 89, 81, 78, 51, 118, 80, 112, 121, 53, 75, 121, 69, 116, 76, 110, 70, 84, 116, 88, 83, 89, 49, 74, 120, 79, 67, 71, 52, 52, 88, 114, 106, 119, 83, 82, 97, 122, 79, 66, 117, 84, 121, 102, 86, 98, 56, 100, 116, 88, 79, 83, 118, 78, 85, 101, 69, 88, 104, 52, 13, 10, 118, 107, 72, 54, 103, 109, 90, 98, 67, 83, 53, 98, 71, 99, 117, 88, 118, 89, 49, 71, 77, 114, 97, 68, 114, 117, 116, 50, 89, 83, 121, 72, 48, 71, 80, 102, 65, 73, 119, 75, 83, 112, 120, 90, 47, 52, 82, 74, 75, 97, 85, 67, 75, 49, 114, 56, 48, 103, 79, 57, 67, 121, 76, 50, 13, 10, 57, 78, 100, 117, 100, 101, 77, 100, 103, 71, 85, 72, 88, 122, 80, 80, 87, 70, 122, 56, 100, 73, 117, 72, 49, 119, 104, 109, 108, 56, 68, 48, 88, 119, 73, 68, 65, 81, 65, 66, 111, 52, 73, 67, 50, 84, 67, 67, 65, 116, 85, 119, 72, 119, 89, 68, 86, 82, 48, 106, 66, 66, 103, 119, 13, 10, 70, 111, 65, 85, 102, 103, 78, 97, 90, 85, 70, 114, 112, 51, 52, 75, 52, 98, 105, 100, 67, 79, 111, 100, 106, 104, 49, 113, 120, 50, 85, 119, 72, 81, 89, 68, 86, 82, 48, 79, 66, 66, 89, 69, 70, 77, 113, 103, 116, 109, 77, 102, 100, 97, 84, 87, 76, 108, 97, 107, 72, 107, 99, 116, 13, 10, 83, 112, 72, 77, 70, 122, 69, 48, 77, 65, 52, 71, 65, 49, 85, 100, 68, 119, 69, 66, 47, 119, 81, 69, 65, 119, 73, 70, 111, 68, 65, 77, 66, 103, 78, 86, 72, 82, 77, 66, 65, 102, 56, 69, 65, 106, 65, 65, 77, 66, 48, 71, 65, 49, 85, 100, 74, 81, 81, 87, 77, 66, 81, 71, 13, 10, 67, 67, 115, 71, 65, 81, 85, 70, 66, 119, 77, 66, 66, 103, 103, 114, 66, 103, 69, 70, 66, 81, 99, 68, 65, 106, 66, 80, 66, 103, 78, 86, 72, 83, 65, 69, 83, 68, 66, 71, 77, 68, 111, 71, 67, 121, 115, 71, 65, 81, 81, 66, 115, 106, 69, 66, 65, 103, 73, 48, 77, 67, 115, 119, 13, 10, 75, 81, 89, 73, 75, 119, 89, 66, 66, 81, 85, 72, 65, 103, 69, 87, 72, 87, 104, 48, 100, 72, 66, 122, 79, 105, 56, 118, 99, 50, 86, 106, 100, 88, 74, 108, 76, 109, 78, 118, 98, 87, 57, 107, 98, 121, 53, 106, 98, 50, 48, 118, 81, 49, 66, 84, 77, 65, 103, 71, 66, 109, 101, 66, 13, 10, 68, 65, 69, 67, 65, 84, 66, 77, 66, 103, 78, 86, 72, 82, 56, 69, 82, 84, 66, 68, 77, 69, 71, 103, 80, 54, 65, 57, 104, 106, 116, 111, 100, 72, 82, 119, 79, 105, 56, 118, 89, 51, 74, 115, 76, 109, 78, 118, 98, 87, 57, 107, 98, 50, 78, 104, 76, 109, 78, 118, 98, 83, 57, 106, 13, 10, 85, 71, 70, 117, 90, 87, 120, 74, 98, 109, 78, 68, 90, 88, 74, 48, 97, 87, 90, 112, 89, 50, 70, 48, 97, 87, 57, 117, 81, 88, 86, 48, 97, 71, 57, 121, 97, 88, 82, 53, 76, 109, 78, 121, 98, 68, 66, 57, 66, 103, 103, 114, 66, 103, 69, 70, 66, 81, 99, 66, 65, 81, 82, 120, 13, 10, 77, 71, 56, 119, 82, 119, 89, 73, 75, 119, 89, 66, 66, 81, 85, 72, 77, 65, 75, 71, 79, 50, 104, 48, 100, 72, 65, 54, 76, 121, 57, 106, 99, 110, 81, 117, 89, 50, 57, 116, 98, 50, 82, 118, 89, 50, 69, 117, 89, 50, 57, 116, 76, 50, 78, 81, 89, 87, 53, 108, 98, 69, 108, 117, 13, 10, 89, 48, 78, 108, 99, 110, 82, 112, 90, 109, 108, 106, 89, 88, 82, 112, 98, 50, 53, 66, 100, 88, 82, 111, 98, 51, 74, 112, 100, 72, 107, 117, 89, 51, 74, 48, 77, 67, 81, 71, 67, 67, 115, 71, 65, 81, 85, 70, 66, 122, 65, 66, 104, 104, 104, 111, 100, 72, 82, 119, 79, 105, 56, 118, 13, 10, 98, 50, 78, 122, 99, 67, 53, 106, 98, 50, 49, 118, 90, 71, 57, 106, 89, 83, 53, 106, 98, 50, 48, 119, 77, 65, 89, 68, 86, 82, 48, 82, 66, 67, 107, 119, 74, 52, 73, 73, 97, 50, 49, 118, 90, 72, 77, 117, 98, 87, 121, 67, 68, 87, 49, 104, 97, 87, 119, 117, 97, 50, 49, 118, 13, 10, 90, 72, 77, 117, 98, 87, 121, 67, 68, 72, 100, 51, 100, 121, 53, 114, 98, 87, 57, 107, 99, 121, 53, 116, 98, 68, 67, 67, 65, 81, 81, 71, 67, 105, 115, 71, 65, 81, 81, 66, 49, 110, 107, 67, 66, 65, 73, 69, 103, 102, 85, 69, 103, 102, 73, 65, 56, 65, 66, 50, 65, 76, 118, 90, 13, 10, 51, 55, 119, 102, 105, 110, 71, 49, 107, 53, 81, 106, 108, 54, 113, 83, 101, 48, 99, 52, 86, 53, 85, 75, 113, 49, 76, 111, 71, 112, 67, 87, 90, 68, 97, 79, 72, 116, 71, 70, 65, 65, 65, 66, 97, 55, 108, 90, 120, 106, 81, 65, 65, 65, 81, 68, 65, 69, 99, 119, 82, 81, 73, 104, 13, 10, 65, 79, 87, 50, 80, 65, 114, 105, 114, 77, 84, 54, 57, 116, 75, 52, 112, 107, 121, 50, 108, 108, 74, 84, 51, 112, 117, 79, 77, 122, 76, 114, 106, 73, 87, 82, 52, 119, 71, 54, 119, 72, 104, 49, 65, 105, 65, 116, 117, 107, 121, 114, 78, 111, 71, 86, 90, 65, 87, 115, 43, 50, 74, 101, 13, 10, 65, 107, 57, 107, 87, 76, 104, 57, 76, 72, 121, 104, 98, 66, 80, 43, 49, 66, 83, 68, 121, 50, 74, 71, 100, 119, 66, 50, 65, 72, 82, 43, 50, 111, 77, 120, 114, 84, 77, 81, 107, 83, 71, 99, 122, 105, 86, 80, 81, 110, 68, 67, 118, 47, 49, 101, 81, 105, 65, 73, 120, 106, 99, 49, 13, 10, 101, 101, 89, 81, 101, 56, 120, 87, 65, 65, 65, 66, 97, 55, 108, 90, 120, 108, 77, 65, 65, 65, 81, 68, 65, 69, 99, 119, 82, 81, 73, 103, 81, 102, 103, 118, 90, 66, 85, 80, 100, 102, 122, 119, 100, 67, 83, 67, 101, 118, 77, 80, 75, 52, 79, 57, 105, 80, 111, 101, 101, 75, 98, 74, 13, 10, 67, 120, 56, 85, 89, 69, 109, 74, 105, 109, 111, 67, 73, 81, 68, 121, 120, 107, 43, 113, 98, 104, 85, 70, 54, 49, 89, 53, 114, 79, 68, 117, 47, 52, 122, 72, 118, 116, 116, 105, 53, 66, 56, 85, 114, 120, 65, 73, 109, 82, 109, 86, 52, 115, 65, 85, 117, 68, 65, 78, 66, 103, 107, 113, 13, 10, 104, 107, 105, 71, 57, 119, 48, 66, 65, 81, 115, 70, 65, 65, 79, 67, 65, 81, 69, 65, 70, 72, 116, 51, 47, 102, 87, 115, 80, 111, 110, 47, 55, 74, 81, 72, 84, 50, 66, 76, 82, 111, 50, 112, 55, 103, 111, 73, 73, 51, 52, 112, 115, 121, 103, 67, 50, 55, 72, 106, 87, 120, 110, 109, 13, 10, 57, 50, 121, 102, 107, 74, 68, 106, 113, 87, 99, 90, 56, 110, 79, 48, 113, 73, 114, 116, 100, 79, 85, 84, 103, 114, 115, 108, 82, 83, 89, 67, 111, 71, 97, 108, 111, 49, 119, 90, 81, 54, 107, 73, 71, 89, 117, 71, 115, 97, 89, 121, 110, 71, 78, 68, 67, 56, 109, 47, 86, 76, 52, 75, 13, 10, 116, 72, 65, 110, 120, 108, 49, 79, 106, 49, 105, 68, 77, 117, 43, 48, 89, 115, 113, 114, 69, 80, 72, 107, 78, 111, 81, 109, 118, 99, 108, 47, 75, 86, 88, 74, 47, 121, 74, 122, 68, 56, 118, 114, 69, 74, 47, 107, 110, 103, 55, 106, 51, 85, 51, 101, 115, 122, 98, 114, 69, 71, 117, 90, 13, 10, 79, 54, 77, 122, 105, 90, 47, 54, 121, 105, 56, 56, 108, 65, 109, 65, 81, 71, 79, 103, 105, 84, 108, 76, 117, 113, 69, 68, 97, 110, 57, 112, 107, 116, 76, 72, 78, 55, 84, 115, 82, 53, 85, 50, 119, 84, 103, 68, 112, 50, 111, 83, 114, 116, 50, 52, 110, 49, 111, 90, 116, 47, 115, 117, 13, 10, 49, 53, 66, 47, 82, 119, 55, 97, 116, 74, 78, 43, 49, 66, 110, 83, 43, 47, 102, 81, 108, 51, 98, 118, 57, 80, 97, 108, 56, 48, 65, 80, 66, 88, 107, 121, 100, 97, 90, 109, 50, 90, 120, 86, 68, 103, 49, 65, 83, 105, 47, 118, 119, 120, 55, 68, 49, 106, 104, 101, 71, 81, 111, 100, 13, 10, 56, 66, 115, 88, 48, 53, 110, 80, 73, 83, 51, 68, 111, 97, 79, 83, 121, 85, 76, 83, 106, 66, 76, 120, 109, 111, 51, 111, 86, 81, 106, 69, 55, 116, 48, 106, 99, 115, 66, 47, 87, 65, 61, 61, 13, 10, 45, 45, 45, 45, 45, 69, 78, 68, 32, 67, 69, 82, 84, 73, 70, 73, 67, 65, 84, 69, 45, 45, 45, 45, 45};
        public byte[] puk = {48, -127, -97, 48, 13, 6, 9, 42, -122, 72, -122, -9, 13, 1, 1, 1, 5, 0, 3, -127, -115, 0, 48, -127, -119, 2, -127, -127, 0, -41, 36, -11, -27, -61, 32, 124, 58, 39, -94, -13, 7, 48, -104, -109, 106, -75, -8, Byte.MIN_VALUE, -92, -89, -125, -49, -83, 75, 12, -26, 90, 56, 35, 52, -116, 30, 40, -69, -70, 86, 14, -80, -20, 55, -89, 104, -46, -17, -80, -119, 83, -14, 116, -66, 11, -108, 5, 76, 12, -43, -89, -49, 11, 38, -124, 71, 45, 65, -103, 10, 99, 33, 79, 21, -16, -38, -60, 24, -108, 101, -89, -18, 48, -37, -78, 59, 10, 89, 42, 51, -43, 9, -33, -68, 61, -45, 94, -49, 83, 52, 56, 105, -123, 18, 89, 3, 54, -48, -63, -61, -103, -9, 79, -36, 18, 119, 11, -35, 82, 73, -66, 12, 123, -38, 97, 121, -30, 31, -50, -106, Byte.MAX_VALUE, 2, 3, 1, 0, 1};

        public DRM() {
        }

        public final void TOAST(String what) throws InterruptedException {
            new Handler(Looper.getMainLooper()).post(new Runnable(what) {
                private final  String f$1;

                {
                    this.f$1 = r2;
                }

                public final void run() {
                    Flutuante.DRM.this.lambda$TOAST$0$Flutuante$DRM(this.f$1);
                }
            });
            Thread.sleep(1200);
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                public final void run() {
                    Flutuante.DRM.this.lambda$TOAST$1$Flutuante$DRM();
                }
            });
        }

        public void lambda$TOAST$0$Flutuante$DRM(String what) {
            Toast.makeText(Flutuante.this, what, 1).show();
        }

        public void lambda$TOAST$1$Flutuante$DRM() {
            Flutuante.this.stopSelf();
        }

        public void run() {
            try {
                if (!Thread.currentThread().isInterrupted()) {
                    Flutuante.this.vpn();
                    String rdToken = Flutuante.rdStr();
                    JSONObject token = new JSONObject();
                    JSONObject data = new JSONObject();
                    data.put(Flutuante.En02(), Prefs.with(Flutuante.this.getBaseContext()).read(this.USER));
                    data.put(Flutuante.En03(), Prefs.with(Flutuante.this.getBaseContext()).read(this.PASS));
                    data.put(Flutuante.En04(), Flutuante.En07());
                    data.put(Flutuante.En05(), Flutuante.this.getUniqueId(Flutuante.this.getBaseContext()));
                    token.put(Flutuante.En08(), RSA.encrypt(data.toString(), this.puk));
                    token.put(Flutuante.En09(), Utils.SHA256(data.toString()));
                    token.put(Flutuante.En06(), rdToken);
                    CertificateFactory cf = CertificateFactory.getInstance("X.509");
                    Certificate ca = cf.generateCertificate(new ByteArrayInputStream(this.crt));
                    KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
                    keyStore.load((InputStream) null, (char[]) null);
                    keyStore.setCertificateEntry("ca", ca);
                    TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()).init(keyStore);
                    HttpURLConnection urlConnection = (HttpURLConnection) new URL(Flutuante.En01()).openConnection();
                    urlConnection.setRequestMethod("POST");
                    urlConnection.setDoInput(true);
                    urlConnection.setDoOutput(true);
                    urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    String postParameters = Flutuante.En11() + Utils.toBase64(token.toString());
                    urlConnection.setFixedLengthStreamingMode(postParameters.getBytes().length);
                    PrintWriter out = new PrintWriter(urlConnection.getOutputStream());
                    out.print(postParameters);
                    out.close();
                    String resp = Utils.readStream(urlConnection.getInputStream());
                    if (!resp.isEmpty()) {
                        JSONObject ack = new JSONObject(Utils.fromBase64String(resp));
                        JSONObject jSONObject = token;
                        String decData = Utils.profileDecrypt(ack.get(Flutuante.En08()).toString(), ack.get(Flutuante.En09()).toString());
                        JSONObject jSONObject2 = data;
                        if (!RSA.verify(decData, ack.get(Flutuante.En10()).toString(), this.puk)) {
                            TOAST("Login Data is Wrong!");
                        }
                        JSONObject data2 = new JSONObject(decData);
                        String str = decData;
                        if (!data2.get(Flutuante.En12()).toString().equals(Flutuante.En13())) {
                            Certificate certificate = ca;
                            TOAST(data2.get(Flutuante.En14()).toString());
                        } else if (!Prefs.with(Flutuante.this.getBaseContext()).read(this.USER).toLowerCase().equals(data2.getString(Flutuante.En17()).toLowerCase())) {
                            TOAST(Flutuante.En22());
                            return;
                        } else if (!Prefs.with(Flutuante.this.getBaseContext()).read(this.PASS).equals(data2.getString(Flutuante.En18()))) {
                            TOAST(Flutuante.En23());
                            return;
                        } else if (!data2.getString(Flutuante.En16()).equals(rdToken)) {
                            TOAST(Flutuante.En24());
                            return;
                        } else if (!Flutuante.isRunning) {
                            Thread.sleep(1200);
                            boolean unused = Flutuante.isRunning = true;
                            CertificateFactory certificateFactory = cf;
                            Flutuante.this.prefs.write(Flutuante.En21(), data2.get(Flutuante.En15()).toString());
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                public final void run() {
                                    Flutuante.this.startServer();
                                }
                            });
                            Certificate certificate2 = ca;
                            Flutuante.init(Prefs.with(Flutuante.this.getBaseContext()).read(this.USER), Prefs.with(Flutuante.this.getBaseContext()).read(this.PASS), Flutuante.this.getUniqueId(Flutuante.this.getBaseContext()), rdToken);
                        } else {
                            Certificate certificate3 = ca;
                        }
                        urlConnection.disconnect();
                        return;
                    }
                    JSONObject jSONObject3 = data;
                    CertificateFactory certificateFactory2 = cf;
                    Certificate certificate4 = ca;
                    TOAST("Ocorreu um erro no servidor!");
                }
            } catch (Exception e) {
                try {
                    e.printStackTrace();
                    TOAST("Error in Background");
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
*/
    public final void startServer() {
        
        modMenu();
    }

    public final void addSwitch(String paramString, int paramInt, final C0094SW listner) {
        final Switch switc = new Switch(this);
        int i = paramInt % 2;
        switc.setTextColor(-1);
        switc.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + paramString + "</b></font>: <font color='#FE0000'>"));
        switc.setShadowLayer(20.0f, 0.0f, 0.0f, Color.parseColor("#db4500"));
        switc.setPadding(10, 5, 0, 5);
        switc.setOnClickListener(new View.OnClickListener() {
            public boolean isActive = true;

            public void onClick(View param1View) {
                listner.OnWrite(this.isActive);
                if (this.isActive) {
                 //   Flutuante.this.vpn();
                    switc.setShadowLayer(20.0f, 0.0f, 0.0f, Color.parseColor("#2EE36D"));
                    switc.getBackground().setAlpha(200);
                    this.isActive = false;
                    return;
                }
                this.isActive = true;
                switc.setShadowLayer(12.0f, 0.0f, 0.0f, Color.parseColor("#db4500"));
            }
        });
        this.patches.addView(switc);
    }

    /*public boolean vpn() {
        String iface = "";
        try {
            Iterator<T> it = Collections.list(NetworkInterface.getNetworkInterfaces()).iterator();
            while (it.hasNext()) {
                NetworkInterface networkInterface = (NetworkInterface) it.next();
                if (networkInterface.isUp()) {
                    iface = networkInterface.getName();
                }
                if (!iface.contains("tun") && !iface.contains("ppp")) {
                    if (iface.contains("pptp")) {
                    }
                }
                stackOverflow();
                return true;
            }
            return false;
        } catch (SocketException e1) {
            e1.printStackTrace();
            return false;
        }
    }
*/
    public final void addSeekBar(String name, int paramInt1, int min, int paramInt3, C0093SB listner) {
        String str = name;
        int i = min;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        TextView textView = new TextView(this);
        textView.setTextColor(Color.parseColor("#ffffff"));
        textView.setShadowLayer(13.0f, 0.0f, 0.0f, Color.parseColor("#db4500"));
        if (str.equals("Esp Cor")) {
            textView.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str + ": <font color='#FE0000'>" + "VERMELHO" + "</b></font>"));
            Object obj = "VERMELHO";
        } else if (str.equals("AimSpot")) {
            textView.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str + ": <font color='#FE0000'>" + "CABEÇA" + "</b></font>"));
            Object obj2 = "CABEÇA";
        } else if (str.equals("AimFov")) {
            textView.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str + ": <font color='#FE0000'>" + "360" + "</b></font>"));
            Object obj3 = "360";
        } else {
            textView.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str + ": <font color='#ffffff'>" + i + "</b></font>"));
            Object obj4 = "";
        }
        SeekBar seek = new SeekBar(this);
        seek.setPadding(25, 10, 35, 10);
        seek.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seek.setMax(paramInt3);
        seek.setProgress(i);
        seek.getProgressDrawable().setColorFilter(Color.parseColor("#B2db4500"), PorterDuff.Mode.MULTIPLY);
        final TextView textView2 = textView;
        final int i3 = min;
        SeekBar seekBar = seek;
        final String str2 = name;
        final SeekBar seekBar2 = seekBar;
        final C0093SB sb = listner;
        SeekBar seekBar3 = seekBar;
        final TextView textView3 = textView;
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar param1SeekBar, int param1Int, boolean param1Boolean) {
                String CorEsp;
                String func2;
                String CorEsp2;
                String func22;
                int i = param1Int;
                if (i < 1) {
                    textView2.setShadowLayer(13.0f, 0.0f, 0.0f, Color.parseColor("#db4500"));
                }
                if (i > 0) {
                    textView2.setShadowLayer(13.0f, 0.0f, 0.0f, Color.parseColor("#2EE36D"));
                }
                int i2 = i3;
                if (i < i2) {
                    seekBar2.setProgress(i2);
                    sb.OnWrite(i3);
                    TextView textView = textView3;
                    textView.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str2 + ": <font color='#ffffff'>" + i3 + "</b></font>"));
                    return;
                }
                sb.OnWrite(i);
                if (i < 1) {
                    if (str2.equals("Esp Cor")) {
                        
                        textView2.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str2 + ": <font color='#FE0000'>" + "VERMELHO" + "</b></font>"));
                    } else if (str2.equals("AimSpot")) {
                        TextView textView3 = textView2;
                        textView3.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str2 + ": <font color='#FE0000'>" + "CABEÇA" + "</b></font>"));
                    } else if (str2.equals("AimFov")) {
                        TextView textView4 = textView2;
                        textView4.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str2 + ": <font color='#FE0000'>" + "360" + "</b></font>"));
                    } else {
                        TextView textView5 = textView2;
                        textView5.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str2 + ": <font color='#ffffff'>" + i + "</b></font>"));
                    }
                }
                if (i <= 0) {
                    return;
                }
                if (str2.equals("Esp Cor")) {
                    if (i == 1) {
                        func22 = "AZUL";
                        CorEsp2 = "#1AA3FF";
                    } else if (i == 2) {
                        func22 = "AZUL";
                        CorEsp2 = "#0000FF";
                    } else if (i == 3) {
                        func22 = "VERDE";
                        CorEsp2 = "#00FF99";
                    } else if (i == 4) {
                        func22 = "VERDE";
                        CorEsp2 = "#00FF00";
                    } else if (i == 5) {
                        func22 = "ROSA";
                        CorEsp2 = "#FE2EC8";
                    } else if (i == 6) {
                        func22 = "ROSA";
                        CorEsp2 = "#FF0066";
                    } else if (i == 7) {
                        func22 = "ROXO";
                        CorEsp2 = "#CC0099";
                    } else if (i == 8) {
                        func22 = "AMARELO";
                        CorEsp2 = "#FFFF00";
                    } else if (i == 9) {
                        func22 = "DOURADO";
                        CorEsp2 = "#FFCC00";
                    } else if (i == 10) {
                        func22 = "MIX";
                        CorEsp2 = "#666699";
                    } else if (i == 11) {
                        func22 = "MIX";
                        CorEsp2 = "#99668C";
                    } else if (i == 12) {
                        func22 = "MIX";
                        CorEsp2 = "#996666";
                    } else if (i == 13) {
                        func22 = "BRANCO";
                        CorEsp2 = "#FFFFFF";
                    } else if (i == 14) {
                        func22 = "LARANJA";
                        CorEsp2 = "#CC6600";
                    } else if (i == 15) {
                        func22 = "VINHO";
                        CorEsp2 = "#996666";
                    } else {
                        func22 = "VERMELHO";
                        CorEsp2 = "#FF0202";
                    }
                    TextView textView6 = textView3;
                    textView6.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str2 + ": <font color='" + CorEsp2 + "'>" + func22 + "</b></font>"));
                } else if (str2.equals("AimSpot")) {
                    if (i == 1) {
                        func2 = "PESCOÇO";
                        CorEsp = "#FFFFFF";
                    } else if (i == 2) {
                        func2 = "PEITO";
                        CorEsp = "#FFFFFF";
                    } else if (i == 3) {
                        func2 = "QUADRIL";
                        CorEsp = "#FFFFFF";
                    } else if (i == 4) {
                        func2 = "PÉ";
                        CorEsp = "#FFFFFF";
                    } else {
                        func2 = "CABEÇA";
                        CorEsp = "#FF0202";
                    }
                    TextView textView7 = textView3;
                    textView7.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str2 + ": <font color='" + CorEsp + "'>" + func2 + "</b></font>"));
                } else {
                    TextView textView8 = textView3;
                    textView8.setText(Html.fromHtml("<font face='sans-serif-black'><b>" + str2 + ": <font color='#ffffff'>" + i + "</b></font>"));
                }
            }

            public void onStartTrackingTouch(SeekBar param1SeekBar) {
            }

            public void onStopTrackingTouch(SeekBar param1SeekBar) {
            }
        });
        linearLayout.addView(textView);
        linearLayout.addView(seekBar3);
        this.patches.addView(linearLayout);
    }

    public final void addSpinner(String featureName, final C0093SB interInt) {
        List<String> list = new LinkedList<>(Arrays.asList(featureName.split("_")));
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 10, 5);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.parseColor("#171E24"));
        TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + list.get(0) + ": <font color='#41c300'></font>"));
        textView.setTextColor(Color.parseColor("#DEEDF6"));
        LinearLayout linearLayout2 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -1);
        layoutParams2.setMargins(10, 2, 10, 5);
        linearLayout2.setOrientation(1);
        linearLayout2.setGravity(17);
        linearLayout2.setBackgroundColor(Color.parseColor("#1C262D"));
        linearLayout2.setLayoutParams(layoutParams2);
        Spinner spinner = new Spinner(this);
        spinner.setPadding(5, 10, 5, 8);
        spinner.setLayoutParams(layoutParams2);
        spinner.getBackground().setColorFilter(1, PorterDuff.Mode.SRC_ATOP);
        list.remove(0);
        ArrayAdapter aa = new ArrayAdapter(this, 17367048, list);
        aa.setDropDownViewResource(17367049);
        spinner.setAdapter(aa);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                ((TextView) parentView.getChildAt(0)).setTextColor(Color.parseColor("#f5f5f5"));
                interInt.OnWrite(position);
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        linearLayout.addView(textView);
        linearLayout2.addView(spinner);
        this.patches.addView(linearLayout);
        this.patches.addView(linearLayout2);
    }

    public final void modMenu() {
       String[] listFT = getListFT();
        for (int i2 = 0; i2 < listFT.length; i2++) {
            String str = listFT[i2];
            final int l2 = i2;
            if (str.contains("TG_")) {
                addSwitch(str.replace("TG_", ""), i2, new C0094SW() {
                    public void OnWrite(boolean param1Boolean) {
                   //   Flutuante.changeToggle(l2);
                    }
                });
            } else if (str.contains("CT_")) {
                addCategory(str.replace("CT_", ""));
            } else if (str.contains("BT_")) {
                addButton(str.replace("BT_", ""), new InterfaceBtn() {
                    public void OnWrite() {
                    //    Flutuante.changeToggle(l2);
                    }
                });
            } else if (str.contains("Spinner_")) {
                addSpinner(str.replace("Spinner_", ""), new C0093SB() {
                    public void OnWrite(int i) {
                    //   Flutuante.changeSeekBar(l2, i);
                    }
                });
            } else if (str.contains("SB_")) {
                String[] arrayOfString1 = str.split("_");
                addSeekBar(arrayOfString1[1], i2, Integer.parseInt(arrayOfString1[2]), Integer.parseInt(arrayOfString1[3]), new C0093SB() {
                    public void OnWrite(int param1Int) {
                  //    Flutuante.changeSeekBar(l2, param1Int);
                    }
                });
            } else {
                addSwitch(str, i2, new C0094SW() {
                    public void OnWrite(boolean param1Boolean) {
                 //       Flutuante.changeToggle(l2);
                    }
                });
            }
        }
    }

    public final void addButton(String feature, final InterfaceBtn interfaceBtn) {
        GradientDrawable botGrad = new GradientDrawable();
        botGrad.setColor(Color.parseColor("#1C262D"));
        setCornerRadius(botGrad, 8.0f);
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        layoutParams.setMargins(7, 5, 7, 5);
        button.setLayoutParams(layoutParams);
        button.setPadding(10, 5, 10, 5);
        button.setTextSize(13.0f);
        button.setTextColor(Color.parseColor("#D5E3EB"));
        button.setGravity(17);
        if (feature.contains("OnOff_")) {
            String feature2 = feature.replace("OnOff_", "");
            button.setText(feature2 + ": OFF");
            button.setBackgroundColor(Color.parseColor("#7f0000"));
            final String feature22 = feature2;
        /*    button.setOnClickListener(new View.OnClickListener(this) {
                public boolean isActive = true;

                public void onClick(View v) {
                    ((C007911) interfaceBtn).OnWrite();
                    if (this.isActive) {
                        Button button = button;
                        button.setText(feature22 + ": ON");
                        button.setBackgroundColor(Color.parseColor("#003300"));
                        this.isActive = false;
                        return;
                    }
                    Button button2 = button;
                    button2.setText(feature22 + ": OFF");
                    button.setBackgroundColor(Color.parseColor("#7f0000"));
                    this.isActive = true;
                }
            });*/
        } else {
            button.setText(feature);
            button.setBackground(botGrad);
            String str = feature;
            button.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                   // (() interfaceBtn).OnWrite();
                }
            });
        }
        this.patches.addView(button);
    }

    public final void addCategory(String text) {
        TextView textView = new TextView(this);
        textView.setBackgroundColor(Color.parseColor("#2F3D4C"));
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(14.0f);
        textView.setTextColor(Color.parseColor("#DEEDF6"));
        textView.setTypeface((Typeface) null, 1);
        textView.setPadding(10, 5, 0, 5);
        this.patches.addView(textView);
    }

    public static String rdStr() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    public final String getUniqueId(Context ctx) {
        return UUID.nameUUIDFromBytes((getDeviceName() + Settings.Secure.getString(ctx.getContentResolver(), "android_id") + Build.HARDWARE).replace(" ", "").getBytes()).toString().replace("-", "");
    }

    public final String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return model;
        }
        return manufacturer + " " + model;
    }

    /* renamed from: dp */
    public final int mo2336dp(int paramInt) {
        return (int) TypedValue.applyDimension(1, (float) paramInt, getResources().getDisplayMetrics());
    }

    public final int dp2px(int paramInt) {
        return (int) ((((float) paramInt) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    public final void setCornerRadius(GradientDrawable gradientDrawable, float f) {
        gradientDrawable.setCornerRadius(f);
    }
}
