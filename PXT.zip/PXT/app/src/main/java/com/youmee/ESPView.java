package com.youmee;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.os.Process;
import android.util.AttributeSet;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ESPView extends View implements Runnable {
    public int FPS = 60;
    public Paint mFilledPaint;
    public Paint mStrokePaint;
    public Paint mTextPaint;
    public Thread mThread;
    public long sleepTime;
    public Date time;

    public ESPView(Context context) {
        super(context, (AttributeSet) null, 0);
        InitializePaints();
        setFocusableInTouchMode(false);
        setBackgroundColor(0);
        this.time = new Date();
        new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        this.sleepTime = (long) (1000 / this.FPS);
        this.mThread = new Thread(this);
        this.mThread.start();
    }

    public void onDraw(Canvas canvas) {
        if (canvas != null && getVisibility() == 0) {
            ClearCanvas(canvas);
            this.time.setTime(System.currentTimeMillis());
            Canvas canvas2 = canvas;
                Flutuante.DrawOn(this, canvas);
        }
    }

    public void run() {
        Process.setThreadPriority(10);
        while (this.mThread.isAlive() && !this.mThread.isInterrupted()) {
            try {
                long t1 = System.currentTimeMillis();
                postInvalidate();
                Thread.sleep(Math.max(Math.min(0, this.sleepTime - (System.currentTimeMillis() - t1)), this.sleepTime));
            } catch (InterruptedException e) {
            }
        }
    }

    public void InitializePaints() {
        this.mStrokePaint = new Paint();
        this.mStrokePaint.setStyle(Paint.Style.STROKE);
        this.mStrokePaint.setAntiAlias(true);
        this.mStrokePaint.setColor(Color.rgb(0, 0, 0));
        this.mFilledPaint = new Paint();
        this.mFilledPaint.setStyle(Paint.Style.FILL);
        this.mFilledPaint.setAntiAlias(true);
        this.mFilledPaint.setColor(Color.rgb(0, 0, 0));
        this.mTextPaint = new Paint();
        this.mTextPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        this.mTextPaint.setAntiAlias(true);
        this.mTextPaint.setColor(Color.rgb(0, 0, 0));
        this.mTextPaint.setTextAlign(Paint.Align.CENTER);
        this.mTextPaint.setStrokeWidth(1.1f);
    }

    public void ClearCanvas(Canvas cvs) {
        cvs.drawColor(0, PorterDuff.Mode.CLEAR);
    }

    public void DrawLine(Canvas cvs, int a, int r, int g, int b, float lineWidth, float fromX, float fromY, float toX, float toY) {
        this.mStrokePaint.setColor(Color.rgb(r, g, b));
        int i = a;
        this.mStrokePaint.setAlpha(a);
        this.mStrokePaint.setStrokeWidth(lineWidth);
        cvs.drawLine(fromX, fromY, toX, toY, this.mStrokePaint);
    }

    public void DrawText(Canvas cvs, int a, int r, int g, int b, String txt, float posX, float posY, float size) {
        this.mTextPaint.setColor(Color.rgb(r, g, b));
        this.mTextPaint.setAlpha(a);
        if (getRight() > 1920 || getBottom() > 1920) {
            this.mTextPaint.setTextSize(4.0f + size);
        } else if (getRight() == 1920 || getBottom() == 1920) {
            this.mTextPaint.setTextSize(2.0f + size);
        } else {
            this.mTextPaint.setTextSize(size);
        }
        cvs.drawText(txt, posX, posY, this.mTextPaint);
    }

    public void DrawCircle(Canvas cvs, int a, int r, int g, int b, float stroke, float posX, float posY, float radius) {
        this.mStrokePaint.setColor(Color.rgb(r, g, b));
        this.mStrokePaint.setAlpha(a);
        this.mStrokePaint.setStrokeWidth(stroke);
        cvs.drawCircle(posX, posY, radius, this.mStrokePaint);
    }

    public void DrawFilledCircle(Canvas cvs, int a, int r, int g, int b, float posX, float posY, float radius) {
        this.mFilledPaint.setColor(Color.rgb(r, g, b));
        this.mFilledPaint.setAlpha(a);
        cvs.drawCircle(posX, posY, radius, this.mFilledPaint);
    }
}
