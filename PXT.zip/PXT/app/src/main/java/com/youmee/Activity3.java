package com.youmee;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

public class Activity3 extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    //    getWindow().setFlags(1024, 1024);
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 123);
        }
        startService(new Intent(this, Flutuante.class));
        
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 123 && Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please allow this permission, so " + getString(2131427367) + " could be drawn.", 1).show();
        }
    }

    public final boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService("activity");
        if (manager == null) {
            return false;
        }
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (Flutuante.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void startPatcher() {
        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
            startFloater();
            return;
        }
        startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 123);
    }

    public final void startFloater() {
        if (!isServiceRunning()) {
            startService(new Intent(this, Flutuante.class));
         //   finish();
            return;
        }
        Toast.makeText(this, "Service Already Running!", 0).show();
    }
}
