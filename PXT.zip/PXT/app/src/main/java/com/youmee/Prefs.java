package com.youmee;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    public static Prefs prefsInstance;
    public SharedPreferences sharedPreferences;

    public Prefs(Context context) {
        Context applicationContext = context.getApplicationContext();
        this.sharedPreferences = applicationContext.getSharedPreferences(context.getPackageName() + "_preferences", 0);
    }

    public static Prefs with(Context context) {
        if (prefsInstance == null) {
            prefsInstance = new Prefs(context);
        }
        return prefsInstance;
    }

    public String read(String what) {
        return this.sharedPreferences.getString(what, "");
    }

    public String read(String what, String defaultString) {
        return this.sharedPreferences.getString(what, defaultString);
    }

    public void write(String where, String what) {
        this.sharedPreferences.edit().putString(where, what).apply();
    }
}
